<?php

//session_start();
//echo '<br><br><br><pre>' . print_r($_SESSION, TRUE) . '</pre>';
//
//$registered_at = date("M-d-Y h:i:s A", time());
//echo $registered_at;


//echo strtotime("12th December 2017"), "\n\n";
//echo strtotime("20-12-2020") . "<br>";
echo strtotime("29-12-2020");
echo "<br>" . strtotime("23-12-2020");
//$nums = array(3, 5,6, 1, 1,  2, 4, 5 , 5, );
//rsort($nums);
//$nums = array_unique($nums);
//print_r($nums) 


//$sr = "648223d8bebafc";
//$pr_id = "1";
//$email = "gregoflash@05gmail.com";
//$elapse_at = 1608652967;
//$link = "https://astroforextrading.com/?sr=" . $sr . "&pri=" . $pr_id . "&email=" . $email . "&et=" . $elapse_at;
//echo $link;
//$n = time() - 1607554800;
//$int_day = $n / (24 * 3600);
//echo $int_day/3;
?>