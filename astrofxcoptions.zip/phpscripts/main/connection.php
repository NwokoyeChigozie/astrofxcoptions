<?php
//sql connection
$link = mysqli_connect("localhost", "astrowgf_astro_adm", "cryptoservice", "astrowgf_astrofxcoptions");
if(mysqli_connect_error()){
    die('ERROR: Unable to connect:' . mysqli_connect_error());
}


//$link1 = mysqli_connect("localhost", "root", "", "skiphistory");
//if(mysqli_connect_error()){
//    die('ERROR: Unable to connect:' . mysqli_connect_error());
//}
    ?>


