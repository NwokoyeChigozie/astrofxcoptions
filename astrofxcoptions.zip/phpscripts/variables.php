<?php

$ipn_urlm = "https://astroforextrading.com/phpscripts/webhook.php";
$private_key = "0dE5a62a7Bf7AE733dccE633Cf152B40c81C9089E08768aD6C0c5153C294E4F1";
$public_key = "4a4f53634e7300a1c90e540a669ef913fa32feadbde160713c45e6ee78648a40";
$merchant_id = "43e4c8764e58968b7f2c2729d1640ba2";
$ipn_secret = "astroforexbitcointradingplatformalwaysavailable";
$debug_email = "gregoflash05@gmail.com";
?>