
<header >
  <div class="header-menu">
    <div class="container">
     


<div class="row">
                            <?php
                                include_once('includes/nav.php');
                                include_once('includes/nav2.php');
                            ?>
      </div>
    </div>
  </div>
          <div class="partnership-intro">
    <div class="container">
      <div class="row">
        <div class="col-md-5 col-sm-5 col-xs-6 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 185.21 188.6">
            <defs>
              <linearGradient id="partner-gradient" x1="130.68" y1="75.64" x2="154.58" y2="75.64" gradientUnits="userSpaceOnUse">
                <stop offset="0" stop-color="#44a5d5"/>
                <stop offset="1" stop-color="#69d2cd"/>
              </linearGradient>
              <linearGradient id="partner-gradient-2" x1="105.21" y1="143.23" x2="129.21" y2="143.23" gradientUnits="userSpaceOnUse">
                <stop offset="0" stop-color="#ffce6c"/>
                <stop offset="1" stop-color="#ffc04a"/>
              </linearGradient>
              <linearGradient id="partner-gradient-3" x1="154.81" y1="112.74" x2="172" y2="112.74" gradientUnits="userSpaceOnUse">
                <stop offset="0" stop-color="#ff6873"/>
                <stop offset="1" stop-color="#ff896c"/>
              </linearGradient>
              <linearGradient id="partner-gradient-4" x1="50.78" y1="24.68" x2="72.71" y2="24.68" xlink:href="#partner-gradient-2"/>
              <linearGradient id="partner-gradient-5" x1="47.31" y1="54.24" x2="62.61" y2="54.24" xlink:href="#partner-gradient"/>
              <linearGradient id="partner-gradient-6" x1="101.95" y1="48.78" x2="118.56" y2="48.78" xlink:href="#partner-gradient-3"/>
              <linearGradient id="partner-gradient-7" x1="77.72" y1="131.52" x2="89.84" y2="131.52" xlink:href="#partner-gradient-2"/>
              <linearGradient id="partner-gradient-8" x1="114.19" y1="108.57" x2="126.93" y2="108.57" xlink:href="#partner-gradient-3"/>
              <linearGradient id="partner-gradient-9" x1="14.68" y1="143.21" x2="29.59" y2="143.21" xlink:href="#partner-gradient-3"/>
              <linearGradient id="partner-gradient-10" x1="9.58" y1="65.36" x2="39.8" y2="65.36" gradientUnits="userSpaceOnUse">
                <stop offset="0" stop-color="#9f95ed"/>
                <stop offset="1" stop-color="#a567a3"/>
              </linearGradient>
              <linearGradient id="partner-gradient-11" x1="136.24" y1="34.56" x2="152.97" y2="34.56" xlink:href="#partner-gradient-10"/>
              <linearGradient id="partner-gradient-12" x1="78.01" y1="158.33" x2="95.87" y2="158.33" xlink:href="#partner-gradient"/>
              <linearGradient id="partner-gradient-13" x1="40.42" y1="124.13" x2="64.82" y2="124.13" xlink:href="#partner-gradient"/>
              <linearGradient id="partner-gradient-14" x1="19.11" y1="104.47" x2="35.38" y2="104.47" xlink:href="#partner-gradient-2"/>
            </defs>
            <title></title>
            <g>
              <path d="M70.82,77.72a14.25,14.25,0,0,1-25.6,12.5" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.75"/>
              <path d="M45.84,93c3.18,6.58,11.45,9.1,18.47,5.65s10.13-11.59,7-18.17" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.73" opacity="0.97"/>
              <path d="M46.5,95.67c2.91,6.08,10.91,8.21,17.88,4.74s10.26-11.21,7.35-17.29" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.71" opacity="0.94"/>
              <path d="M47.19,98.36c2.63,5.59,10.38,7.31,17.29,3.83s10.39-10.82,7.76-16.41" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.69" opacity="0.91"/>
              <path d="M47.92,101c2.36,5.1,9.84,6.41,16.71,2.93S75.15,93.5,72.79,88.4" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.67" opacity="0.88"/>
              <path d="M48.69,103.62c2.09,4.6,9.31,5.51,16.12,2s10.65-10,8.56-14.65" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.65" opacity="0.85"/>
              <path d="M49.49,106.19c1.82,4.11,8.77,4.61,15.54,1.12s10.78-9.66,9-13.77" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.63" opacity="0.82"/>
              <path d="M50.33,108.72c1.54,3.62,8.24,3.71,15,.21S76.19,99.66,74.65,96" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.62" opacity="0.78"/>
              <path d="M51.21,111.21c1.27,3.13,7.7,2.81,14.37-.69s11-8.89,9.76-12" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.6" opacity="0.75"/>
              <path d="M52.13,113.64c1,2.63,7.17,1.92,13.78-1.6s11.16-8.5,10.17-11.13" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.58" opacity="0.72"/>
              <path d="M53.08,116c0.73,2.14,6.63,1,13.19-2.5s11.29-8.11,10.57-10.25" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.56" opacity="0.69"/>
              <path d="M54.07,118.32c0.45,1.65,6.1.12,12.61-3.41s11.42-7.73,11-9.37" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.54" opacity="0.66"/>
              <path d="M55.09,120.56c0.18,1.15,5.56-.78,12-4.32s11.55-7.34,11.37-8.49" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.52" opacity="0.63"/>
              <path d="M56.16,122.71c-0.09.66,5-1.68,11.44-5.22s11.68-7,11.77-7.61" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.5" opacity="0.6"/>
              <path d="M57.28,124.78c-0.37.17,4.49-2.58,10.85-6.13s11.81-6.57,12.18-6.73" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.48" opacity="0.57"/>
              <path d="M58.45,126.79c-0.64-.33,4-3.47,10.27-7s11.94-6.18,12.58-5.85" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.46" opacity="0.54"/>
              <path d="M59.69,128.82c-0.91-.82,3.42-4.37,9.68-7.94s12.07-5.79,13-5" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.44" opacity="0.51"/>
              <path d="M61,130.88c-1.18-1.31,2.89-5.27,9.1-8.84s12.2-5.41,13.38-4.09" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.42" opacity="0.48"/>
              <path d="M62.36,133c-1.46-1.81,2.35-6.17,8.51-9.75s12.33-5,13.78-3.21" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.4" opacity="0.45"/>
              <path d="M63.78,135.06c-1.73-2.3,1.82-7.07,7.92-10.66s12.46-4.63,14.18-2.33" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.38" opacity="0.42"/>
              <path d="M65.27,137.17c-2-2.79,1.28-8,7.34-11.56s12.58-4.24,14.59-1.45" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.37" opacity="0.38"/>
              <path d="M66.82,139.28c-2.27-3.28.75-8.87,6.75-12.47s12.71-3.86,15-.57" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.35" opacity="0.35"/>
              <path d="M68.43,141.38c-2.55-3.78.22-9.76,6.17-13.37s12.84-3.47,15.39.31" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.33" opacity="0.32"/>
              <path d="M70.11,143.47c-2.82-4.27-.32-10.66,5.58-14.28s13-3.08,15.79,1.19" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.31" opacity="0.29"/>
              <path d="M71.85,145.55c-3.09-4.76-.85-11.56,5-15.18s13.1-2.7,16.19,2.07" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.29" opacity="0.26"/>
              <path d="M73.66,147.61c-3.36-5.26-1.39-12.46,4.41-16.09s13.23-2.31,16.59,2.95" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.27" opacity="0.23"/>
              <path d="M75.53,149.65a12.32,12.32,0,1,1,20.82-13.17" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.2"/>
            </g>
            <g>
              <path d="M184.44,102.34A11.65,11.65,0,1,1,168.89,85" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.75"/>
              <path d="M168.21,87.8c-4.6,3.89-4.79,10.78-.42,15.4s11.64,5.21,16.24,1.32" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.73" opacity="0.97"/>
              <path d="M167.48,90.61c-4.41,3.48-4.38,9.91.06,14.35s11.62,5.22,16,1.74" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.71" opacity="0.94"/>
              <path d="M166.71,93.42c-4.22,3.08-4,9,.55,13.3s11.6,5.23,15.82,2.15" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.69" opacity="0.91"/>
              <path d="M165.9,96.23c-4,2.67-3.56,8.15,1,12.24s11.58,5.24,15.61,2.57" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.67" opacity="0.88"/>
              <path d="M165.05,99c-3.83,2.27-3.15,7.28,1.51,11.19s11.56,5.25,15.39,3" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.65" opacity="0.85"/>
              <path d="M164.16,101.81c-3.64,1.86-2.75,6.4,2,10.14s11.54,5.26,15.18,3.39" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.63" opacity="0.82"/>
              <path d="M163.23,104.58c-3.45,1.46-2.34,5.52,2.48,9.08s11.52,5.27,15,3.81" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.62" opacity="0.78"/>
              <path d="M162.25,107.33c-3.26,1.05-1.93,4.65,3,8s11.5,5.27,14.76,4.22" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.6" opacity="0.75"/>
              <path d="M161.24,110.06c-3.06.65-1.52,3.77,3.45,7s11.48,5.28,14.54,4.64" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.58" opacity="0.72"/>
              <path d="M160.2,112.75c-2.87.24-1.11,2.89,3.94,5.92s11.46,5.29,14.33,5.05" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.56" opacity="0.69"/>
              <path d="M159.11,115.41c-2.68-.16-0.7,2,4.42,4.87s11.44,5.3,14.12,5.47" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.54" opacity="0.66"/>
              <path d="M158,118.11c-2.49-.57-0.29,1.14,4.9,3.82s11.42,5.31,13.91,5.88" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.52" opacity="0.63"/>
              <path d="M156.84,120.87c-2.29-1,.12.26,5.39,2.76s11.4,5.32,13.69,6.3" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.5" opacity="0.6"/>
              <path d="M155.65,123.7c-2.1-1.38.53-.61,5.87,1.71A122.71,122.71,0,0,1,175,132.13" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.48" opacity="0.57"/>
              <path d="M154.43,126.6c-1.91-1.79.94-1.49,6.36,0.66s11.36,5.34,13.27,7.12" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.46" opacity="0.54"/>
              <path d="M153.18,129.56c-1.72-2.19,1.35-2.37,6.84-.4s11.34,5.35,13.06,7.54" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.44" opacity="0.51"/>
              <path d="M151.89,132.57c-1.52-2.6,1.76-3.25,7.33-1.45s11.32,5.36,12.84,8" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.42" opacity="0.48"/>
              <path d="M150.57,135.63c-1.33-3,2.17-4.12,7.81-2.5s11.3,5.37,12.63,8.37" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.4" opacity="0.45"/>
              <path d="M149.22,138.71c-1.14-3.41,2.57-5,8.29-3.56s11.28,5.38,12.42,8.78" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.38" opacity="0.42"/>
              <path d="M147.84,141.83c-0.95-3.81,3-5.88,8.78-4.61s11.26,5.38,12.2,9.2" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.37" opacity="0.38"/>
              <path d="M146.43,145c-0.75-4.22,3.39-6.75,9.26-5.66s11.24,5.39,12,9.61" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.35" opacity="0.35"/>
              <path d="M145,148.12c-0.56-4.62,3.8-7.63,9.75-6.72s11.22,5.4,11.78,10" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.33" opacity="0.32"/>
              <path d="M143.52,151.29c-0.37-5,4.21-8.51,10.23-7.77S165,148.94,165.32,154" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.31" opacity="0.29"/>
              <path d="M142,154.48c-0.18-5.43,4.62-9.38,10.72-8.82s11.18,5.42,11.35,10.86" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.29" opacity="0.26"/>
              <path d="M140.5,157.67c0-5.84,5-10.26,11.2-9.88s11.16,5.43,11.14,11.27" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.27" opacity="0.23"/>
              <path d="M138.95,160.87a11.31,11.31,0,0,1,22.61.75" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.2"/>
            </g>
            <g>
              <path d="M100.89,50.52A9.56,9.56,0,1,1,88.13,36.27" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.75" opacity="0.2"/>
              <path d="M86.08,37.52c-3.7,3.12-3.73,8.78-.08,12.65s9.61,4.47,13.31,1.35" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.73" opacity="0.21"/>
              <path d="M84.06,38.79c-3.46,2.72-3.2,8,.58,11.8s9.66,4.68,13.13,2" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.71" opacity="0.22"/>
              <path d="M82.08,40.07c-3.23,2.31-2.67,7.22,1.25,10.95S93,55.9,96.26,53.59" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.69" opacity="0.23"/>
              <path d="M80.13,41.38c-3,1.91-2.14,6.43,1.91,10.1s9.76,5.08,12.75,3.17" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.67" opacity="0.25"/>
              <path d="M78.23,42.69c-2.76,1.51-1.6,5.65,2.58,9.25s9.8,5.29,12.56,3.78" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.65" opacity="0.26"/>
              <path d="M76.36,44c-2.52,1.11-1.07,4.87,3.24,8.4S89.45,57.91,92,56.8" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.63" opacity="0.27"/>
              <path d="M74.53,45.34c-2.29.7-.54,4.08,3.91,7.55s9.9,5.7,12.19,5" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.62" opacity="0.28"/>
              <path d="M72.74,46.67c-2.05.3,0,3.3,4.57,6.69s9.95,5.9,12,5.6" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.6" opacity="0.29"/>
              <path d="M71,48c-1.82-.1.53,2.52,5.23,5.84S86.21,59.94,88,60" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.58" opacity="0.3"/>
              <path d="M69.27,49.37c-1.58-.5,1.06,1.73,5.9,5s10,6.31,11.62,6.81" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.56" opacity="0.32"/>
              <path d="M67.59,50.82c-1.35-.91,1.59.95,6.56,4.14s10.09,6.52,11.44,7.42" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.54" opacity="0.33"/>
              <path d="M65.95,52.36c-1.11-1.31,2.13.17,7.23,3.29s10.14,6.72,11.25,8" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.52" opacity="0.34"/>
              <path d="M64.34,54c-0.88-1.71,2.66-.62,7.89,2.44S82.42,63.34,83.29,65" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.5" opacity="0.35"/>
              <path d="M62.77,55.66c-0.64-2.11,3.19-1.4,8.56,1.59s10.23,7.13,10.87,9.24" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.48" opacity="0.36"/>
              <path d="M61.24,57.41c-0.4-2.52,3.72-2.18,9.22.74S80.74,65.48,81.14,68" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.46" opacity="0.37"/>
              <path d="M59.74,59.23c-0.17-2.92,4.26-3,9.88-.11s10.33,7.54,10.5,10.46" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.44" opacity="0.38"/>
              <path d="M58.27,61.1c0.07-3.32,4.79-3.75,10.55-1s10.38,7.74,10.31,11.06" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.42" opacity="0.4"/>
              <path d="M56.82,63c0.3-3.72,5.32-4.54,11.21-1.81s10.42,7.95,10.12,11.67" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.4" opacity="0.41"/>
              <path d="M55.39,65c0.54-4.13,5.85-5.32,11.88-2.66S77.74,70.5,77.2,74.63" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.38" opacity="0.42"/>
              <path d="M54,67c0.77-4.53,6.39-6.1,12.54-3.51S77,71.89,76.26,76.41" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.37" opacity="0.43"/>
              <path d="M52.58,69.12c1-4.93,6.92-6.89,13.21-4.37s10.57,8.56,9.56,13.49" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.35" opacity="0.44"/>
              <path d="M51.2,71.24c1.24-5.33,7.45-7.67,13.87-5.22s10.61,8.77,9.37,14.1" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.33" opacity="0.45"/>
              <path d="M49.83,73.4c1.48-5.74,8-8.45,14.53-6.07S75,76.3,73.55,82" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.31" opacity="0.47"/>
              <path d="M48.49,75.6c1.71-6.14,8.52-9.24,15.2-6.92s10.71,9.17,9,15.31" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.29" opacity="0.48"/>
              <path d="M47.17,77.84c1.95-6.54,9.05-10,15.86-7.77S73.78,79.45,71.84,86" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.27" opacity="0.49"/>
              <path d="M45.86,80.12A13.18,13.18,0,1,1,71,88" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.5"/>
            </g>
            <g>
              <path d="M201,137a7.45,7.45,0,0,1-9.94-11.1" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.75"/>
              <path d="M189.61,127.89c-2.87,2.4-2.87,6.8,0,9.82s7.54,3.53,10.42,1.13" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.73" opacity="0.97"/>
              <path d="M188.13,129.82c-2.68,2.06-2.41,6.14.6,9.12s7.63,3.73,10.31,1.67" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.71" opacity="0.94"/>
              <path d="M186.62,131.68c-2.49,1.71-2,5.48,1.2,8.42s7.71,3.93,10.2,2.22" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.69" opacity="0.91"/>
              <path d="M185.06,133.46c-2.29,1.37-1.49,4.82,1.79,7.72s7.8,4.14,10.09,2.77" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.67" opacity="0.88"/>
              <path d="M183.45,135.14c-2.1,1-1,4.16,2.38,7s7.89,4.34,10,3.32" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.65" opacity="0.85"/>
              <path d="M181.81,136.74c-1.91.68-.58,3.5,3,6.31s8,4.54,9.88,3.86" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.63" opacity="0.82"/>
              <path d="M180.12,138.25c-1.71.33-.12,2.84,3.56,5.61s8.06,4.74,9.77,4.41" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.62" opacity="0.78"/>
              <path d="M178.4,139.65c-1.52,0,.34,2.18,4.15,4.91s8.14,4.95,9.66,5" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.6" opacity="0.75"/>
              <path d="M176.62,141c-1.33-.36.8,1.53,4.75,4.21s8.23,5.15,9.55,5.51" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.58" opacity="0.72"/>
              <path d="M174.81,142.33c-1.13-.7,1.26.87,5.34,3.51s8.31,5.35,9.45,6.05" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.56" opacity="0.69"/>
              <path d="M172.95,143.64c-0.94-1,1.71.21,5.93,2.8s8.4,5.55,9.34,6.6" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.54" opacity="0.66"/>
              <path d="M171,144.93c-0.75-1.39,2.17-.45,6.52,2.1s8.48,5.75,9.23,7.15" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.52" opacity="0.63"/>
              <path d="M169.1,146.19c-0.55-1.74,2.63-1.11,7.11,1.4s8.57,6,9.12,7.69" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.5" opacity="0.6"/>
              <path d="M167.1,147.42c-0.36-2.08,3.09-1.77,7.71.7s8.65,6.16,9,8.24" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.48" opacity="0.57"/>
              <path d="M165.06,148.61c-0.17-2.43,3.55-2.43,8.3,0s8.74,6.36,8.91,8.79" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.46" opacity="0.54"/>
              <path d="M163,149.77c0-2.77,4-3.09,8.89-.71s8.83,6.56,8.8,9.34" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.44" opacity="0.51"/>
              <path d="M160.83,150.88c0.22-3.12,4.46-3.75,9.48-1.41s8.91,6.77,8.69,9.88" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.42" opacity="0.48"/>
              <path d="M158.63,152c0.41-3.46,4.92-4.41,10.07-2.11s9,7,8.59,10.43" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.4" opacity="0.45"/>
              <path d="M156.36,153c0.6-3.81,5.38-5.07,10.67-2.81s9.08,7.17,8.48,11" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.38" opacity="0.42"/>
              <path d="M154,154c0.8-4.15,5.84-5.73,11.26-3.51s9.17,7.37,8.37,11.53" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.37" opacity="0.38"/>
              <path d="M151.66,154.89c1-4.5,6.3-6.38,11.85-4.21s9.25,7.58,8.26,12.07" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.35" opacity="0.35"/>
              <path d="M149.22,155.77c1.18-4.84,6.75-7,12.44-4.92s9.34,7.78,8.15,12.62" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.33" opacity="0.32"/>
              <path d="M146.72,156.6c1.38-5.19,7.21-7.7,13-5.62s9.42,8,8,13.17" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.31" opacity="0.29"/>
              <path d="M144.16,157.39c1.57-5.53,7.67-8.36,13.63-6.32s9.51,8.18,7.94,13.72" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.29" opacity="0.26"/>
              <path d="M141.55,158.12a11,11,0,0,1,14.22-7,11.72,11.72,0,0,1,7.83,14.26" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.27" opacity="0.23"/>
              <path d="M138.87,158.79a11.81,11.81,0,1,1,22.53,7.09" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.2"/>
            </g>
            <g>
              <path d="M61.06,158.73a6.7,6.7,0,0,1-11,7.72" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.75"/>
              <path d="M52.71,168c1.9,2.81,5.89,3.3,8.9,1.11s3.91-6.25,2-9.06" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.73" opacity="0.97"/>
              <path d="M55.29,169.52c1.67,2.59,5.46,2.85,8.46.59s4.07-6.19,2.4-8.78" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.71" opacity="0.94"/>
              <path d="M57.86,171c1.45,2.37,5,2.4,8,.08s4.23-6.13,2.79-8.5" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.69" opacity="0.91"/>
              <path d="M60.41,172.35c1.22,2.15,4.61,2,7.58-.43s4.39-6.07,3.17-8.22" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.67" opacity="0.88"/>
              <path d="M62.94,173.67c1,1.93,4.19,1.51,7.14-.95s4.55-6,3.56-7.94" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.65" opacity="0.85"/>
              <path d="M65.45,174.92c0.76,1.71,3.76,1.06,6.71-1.46s4.71-5.95,4-7.66" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.63" opacity="0.82"/>
              <path d="M67.94,176.09c0.53,1.49,3.34.61,6.27-2s4.87-5.89,4.34-7.38" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.62" opacity="0.78"/>
              <path d="M70.4,177.2c0.3,1.27,2.91.16,5.83-2.49s5-5.83,4.73-7.1" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.6" opacity="0.75"/>
              <path d="M72.85,178.23c0.07,1.06,2.49-.29,5.39-3s5.19-5.77,5.12-6.82" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.58" opacity="0.72"/>
              <path d="M75.28,179.18c-0.15.84,2.06-.74,5-3.51s5.35-5.71,5.51-6.54" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.56" opacity="0.69"/>
              <path d="M77.71,180c-0.38.62,1.64-1.19,4.51-4a78.11,78.11,0,0,0,5.9-6.26" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.54" opacity="0.66"/>
              <path d="M80.16,180.84c-0.61.4,1.21-1.64,4.07-4.54a86.62,86.62,0,0,1,6.29-6" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.52" opacity="0.63"/>
              <path d="M82.62,181.54c-0.84.18,0.79-2.08,3.63-5.05s5.83-5.52,6.67-5.7" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.5" opacity="0.6"/>
              <path d="M85.09,182.17c-1.07,0,.36-2.53,3.2-5.57s6-5.46,7.06-5.42" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.48" opacity="0.57"/>
              <path d="M87.57,182.73c-1.3-.26-0.06-3,2.76-6.08s6.16-5.4,7.45-5.14" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.46" opacity="0.54"/>
              <path d="M90.05,183.23c-1.52-.48-0.49-3.43,2.32-6.59s6.32-5.34,7.84-4.86" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.44" opacity="0.51"/>
              <path d="M92.55,183.66c-1.75-.7-0.91-3.88,1.88-7.11s6.48-5.28,8.23-4.58" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.42" opacity="0.48"/>
              <path d="M95,184c-2-.92-1.34-4.33,1.44-7.62s6.64-5.22,8.62-4.31" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.4" opacity="0.45"/>
              <path d="M97.56,184.35c-2.21-1.13-1.76-4.78,1-8.13s6.8-5.16,9-4" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.38" opacity="0.42"/>
              <path d="M100.07,184.58c-2.44-1.35-2.19-5.23.56-8.65s7-5.1,9.4-3.75" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.37" opacity="0.38"/>
              <path d="M102.58,184.75c-2.67-1.57-2.61-5.67.13-9.16s7.12-5,9.78-3.47" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.35" opacity="0.35"/>
              <path d="M105.11,184.84c-2.9-1.79-3-6.12-.31-9.68s7.28-5,10.17-3.19" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.33" opacity="0.32"/>
              <path d="M107.63,184.85c-3.12-2-3.46-6.57-.75-10.19s7.44-4.92,10.56-2.91" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.31" opacity="0.29"/>
              <path d="M110.16,184.78c-3.35-2.23-3.89-7-1.19-10.7s7.6-4.86,11-2.63" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.29" opacity="0.26"/>
              <path d="M112.69,184.64a7.9,7.9,0,0,1-1.63-11.22,8.32,8.32,0,0,1,11.34-2.35" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.27" opacity="0.23"/>
              <path d="M115.22,184.4a8.42,8.42,0,1,1,9.66-13.8" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.2"/>
              <path d="M123.41,169.82c-3.67-2.31-8.93-1.22-11.74,2.44s-2.13,8.5,1.54,10.81" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.23"/>
              <path d="M122,169c-3.53-2-8.79-.7-11.76,2.8s-2.51,7.94,1,9.89" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.26"/>
              <path d="M120.59,168.25c-3.39-1.6-8.66-.18-11.77,3.17s-2.9,7.37.49,9" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.29"/>
              <path d="M119.24,167.46c-3.24-1.25-8.52.34-11.79,3.54s-3.29,6.81,0,8.06" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.32"/>
              <path d="M117.92,166.68c-3.1-.89-8.39.86-11.81,3.91s-3.67,6.25-.57,7.14" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.35"/>
              <path d="M116.64,165.9c-3-.54-8.25,1.38-11.82,4.28s-4.06,5.69-1.1,6.22" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.38"/>
              <path d="M115.39,165.15c-2.82-.18-8.12,1.9-11.84,4.65s-4.44,5.12-1.62,5.31" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.42"/>
              <path d="M114.18,164.41c-2.68.17-8,2.42-11.85,5s-4.83,4.56-2.15,4.39" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.45"/>
              <path d="M113,163.61c-2.54.53-7.85,2.94-11.87,5.38s-5.22,4-2.68,3.47" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.48"/>
              <path d="M111.87,162.76A114.88,114.88,0,0,0,100,168.51c-4.17,2.29-5.6,3.44-3.21,2.55" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.51"/>
              <path d="M110.76,161.83c-2.25,1.24-7.58,4-11.9,6.12s-6,2.87-3.73,1.64" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.54"/>
              <path d="M109.68,160.84a77.87,77.87,0,0,1-11.91,6.49c-4.47,2-6.37,2.31-4.26.72" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.57"/>
              <path d="M108.64,159.79c-2,1.95-7.31,5-11.93,6.86s-6.76,1.75-4.79-.2" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.6"/>
              <path d="M107.63,158.68c-1.83,2.3-7.18,5.54-11.94,7.22s-7.15,1.19-5.32-1.12" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.63"/>
              <path d="M106.65,157.52c-1.69,2.66-7,6.06-12,7.59s-7.53.62-5.84-2" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.66"/>
              <path d="M105.7,156.32c-1.55,3-6.91,6.58-12,8s-7.92.06-6.37-3" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.69"/>
              <path d="M104.78,155.08c-1.41,3.37-6.77,7.1-12,8.33s-8.3-.5-6.9-3.87" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.72"/>
              <path d="M103.89,153.82c-1.26,3.72-6.64,7.62-12,8.7s-8.69-1.06-7.42-4.79" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.75"/>
              <path d="M103,152.53c-1.12,4.08-6.5,8.14-12,9.07s-9.08-1.63-8-5.7" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.78"/>
              <path d="M102.19,151.21c-1,4.43-6.37,8.66-12,9.43s-9.46-2.19-8.48-6.62" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.82"/>
              <path d="M101.39,149.88c-0.84,4.79-6.24,9.18-12.05,9.8s-9.85-2.75-9-7.54" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.85"/>
              <path d="M100.61,148.52c-0.7,5.14-6.1,9.7-12.07,10.17s-10.23-3.31-9.53-8.46" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.88"/>
              <path d="M99.85,147.15c-0.56,5.5-6,10.22-12.08,10.54s-10.62-3.88-10.06-9.37" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.91"/>
              <path d="M99.12,145.76c-0.42,5.85-5.83,10.74-12.1,10.91s-11-4.44-10.59-10.29" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.94"/>
              <path d="M98.42,144.36A12.11,12.11,0,0,1,86.3,155.63a10.81,10.81,0,0,1-11.12-11.21" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25" opacity="0.97"/>
              <path d="M97.73,143.18A11.89,11.89,0,1,1,74,142.7" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25"/>
            </g>
            <g>
              <path d="M101.5,36.06A9.77,9.77,0,0,1,88.58,50.73" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.75" opacity="0.2"/>
              <path d="M91.52,52c3.73,3.38,9.58,2.82,13.06-1.24s3.28-10.09-.45-13.46" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.73" opacity="0.23"/>
              <path d="M94.5,53.19c3.41,3.18,8.93,2.47,12.33-1.6s3.39-9.95,0-13.13" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.71" opacity="0.26"/>
              <path d="M97.52,54.31c3.09,3,8.29,2.12,11.6-2s3.5-9.81.41-12.8" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.69" opacity="0.29"/>
              <path d="M100.59,55.37c2.77,2.8,7.64,1.76,10.87-2.32s3.61-9.67.84-12.47" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.67" opacity="0.32"/>
              <path d="M103.69,56.35c2.45,2.61,7,1.41,10.14-2.68s3.72-9.53,1.27-12.14" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.65" opacity="0.35"/>
              <path d="M106.82,57.26c2.13,2.42,6.35,1.06,9.41-3s3.83-9.39,1.69-11.81" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.63" opacity="0.38"/>
              <path d="M110,58.1c1.81,2.23,5.7.7,8.68-3.4s3.93-9.25,2.12-11.47" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.62" opacity="0.42"/>
              <path d="M113.17,58.88c1.49,2,5.05.35,8-3.76s4-9.11,2.55-11.14" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.6" opacity="0.45"/>
              <path d="M116.38,59.58c1.17,1.85,4.41,0,7.22-4.13s4.15-9,3-10.81" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.58" opacity="0.48"/>
              <path d="M119.6,60.2c0.85,1.66,3.76-.35,6.49-4.49s4.26-8.83,3.41-10.48" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.56" opacity="0.51"/>
              <path d="M122.83,60.76c0.53,1.46,3.11-.71,5.76-4.85s4.37-8.69,3.84-10.15" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.54" opacity="0.54"/>
              <path d="M126.06,61.25c0.21,1.27,2.47-1.06,5-5.21s4.48-8.55,4.26-9.82" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.52" opacity="0.57"/>
              <path d="M129.3,61.66c-0.11,1.08,1.82-1.41,4.3-5.57s4.59-8.41,4.69-9.49" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.5" opacity="0.6"/>
              <path d="M132.58,62c-0.43.89,1.17-1.76,3.57-5.93s4.69-8.27,5.12-9.16" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.48" opacity="0.63"/>
              <path d="M135.93,62.27c-0.75.7,0.53-2.12,2.84-6.29s4.8-8.13,5.55-8.83" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.46" opacity="0.66"/>
              <path d="M139.35,62.46c-1.07.51-.12-2.47,2.11-6.65s4.91-8,6-8.5" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.44" opacity="0.69"/>
              <path d="M142.83,62.59c-1.39.32-.77-2.82,1.38-7s5-7.85,6.41-8.17" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.42" opacity="0.72"/>
              <path d="M146.36,62.64c-1.71.13-1.41-3.18,0.65-7.38s5.13-7.71,6.84-7.83" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.4" opacity="0.75"/>
              <path d="M149.94,62.61c-2-.06-2.06-3.53-0.08-7.74s5.24-7.57,7.26-7.5" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.38" opacity="0.78"/>
              <path d="M153.57,62.53c-2.35-.26-2.71-3.88-0.81-8.1s5.35-7.43,7.69-7.17" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.37" opacity="0.82"/>
              <path d="M157.24,62.39c-2.67-.45-3.36-4.23-1.54-8.46s5.45-7.29,8.12-6.84" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.35" opacity="0.85"/>
              <path d="M160.94,62.2c-3-.64-4-4.59-2.27-8.82s5.56-7.15,8.55-6.51" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.33" opacity="0.88"/>
              <path d="M164.66,61.94c-3.31-.83-4.65-4.94-3-9.18s5.67-7,9-6.18" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.31" opacity="0.91"/>
              <path d="M168.41,61.63c-3.63-1-5.3-5.29-3.73-9.54s5.78-6.87,9.41-5.85" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.29" opacity="0.94"/>
              <path d="M172.18,61.27c-3.95-1.21-5.94-5.64-4.46-9.9s5.89-6.73,9.83-5.52" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.27" opacity="0.97"/>
              <path d="M176,60.84A8.13,8.13,0,0,1,181,45.39" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.25"/>
            </g>
            <g>
              <path d="M124,88.39c4.73,0,8.58-1.15,8.58,3.58,0,3.88-2.7,6.37-6.65,7.78,6.84,0.78,10.07,6.33,10.07,13.35" transform="translate(-33.03 -18.41)" fill="none" stroke="#2090ec" stroke-miterlimit="10" stroke-width="0.36" opacity="0.09"/>
              <path d="M137.17,111.59c-0.16-6.47-3.47-11.7-10.1-12.57a14.17,14.17,0,0,0,1.49-.68c2.8-1.48,4.62-3.76,4.61-7,0-4.59-3.6-3.63-8-3.73" transform="translate(-33.03 -18.41)" fill="none" stroke="#2291ec" stroke-miterlimit="10" stroke-width="0.4" opacity="0.1"/>
              <path d="M138.28,109.94c-0.32-5.92-3.7-10.82-10.14-11.79a12.67,12.67,0,0,0,1.35-.68,7.68,7.68,0,0,0,4.2-6.89c0-4.46-3.35-3.69-7.36-3.88" transform="translate(-33.03 -18.41)" fill="none" stroke="#2492ec" stroke-miterlimit="10" stroke-width="0.43" opacity="0.11"/>
              <path d="M139.33,108.14a11.8,11.8,0,0,0-10.17-11,11.16,11.16,0,0,0,1.21-.69,7.74,7.74,0,0,0,3.79-6.79c0-4.32-3.1-3.74-6.76-4" transform="translate(-33.03 -18.41)" fill="none" stroke="#2793ed" stroke-miterlimit="10" stroke-width="0.47" opacity="0.12"/>
              <path d="M140.33,106.2c-0.65-4.81-4.18-9.07-10.21-10.22a9.83,9.83,0,0,0,1.08-.69,7.88,7.88,0,0,0,3.38-6.69c0-4.18-2.85-3.8-6.15-4.18" transform="translate(-33.03 -18.41)" fill="none" stroke="#2994ed" stroke-miterlimit="10" stroke-width="0.51" opacity="0.13"/>
              <path d="M141.27,104.14c-0.81-4.26-4.41-8.2-10.24-9.44A8.71,8.71,0,0,0,132,94a8.14,8.14,0,0,0,3-6.58c0-4-2.6-3.85-5.54-4.33" transform="translate(-33.03 -18.41)" fill="none" stroke="#2b96ed" stroke-miterlimit="10" stroke-width="0.54" opacity="0.14"/>
              <path d="M142.15,102c-1-3.71-4.65-7.33-10.27-8.66a7.82,7.82,0,0,0,.8-0.7,8.6,8.6,0,0,0,2.56-6.48c0-3.91-2.35-3.91-4.93-4.48" transform="translate(-33.03 -18.41)" fill="none" stroke="#2d97ed" stroke-miterlimit="10" stroke-width="0.58" opacity="0.15"/>
              <path d="M143,99.71c-1.13-3.16-4.89-6.45-10.31-7.87a7.22,7.22,0,0,0,.67-0.7,9.35,9.35,0,0,0,2.15-6.38c-0.06-3.77-2.1-4-4.32-4.63" transform="translate(-33.03 -18.41)" fill="none" stroke="#3098ed" stroke-miterlimit="10" stroke-width="0.61" opacity="0.16"/>
              <path d="M143.74,97.39c-1.3-2.6-5.12-5.58-10.34-7.09a7.06,7.06,0,0,0,.53-0.7,10.61,10.61,0,0,0,1.74-6.27c-0.06-3.63-1.85-4-3.71-4.78" transform="translate(-33.03 -18.41)" fill="none" stroke="#3299ed" stroke-miterlimit="10" stroke-width="0.65" opacity="0.17"/>
              <path d="M144.44,95c-1.46-2.05-5.36-4.71-10.38-6.31a7.71,7.71,0,0,0,.39-0.71,12.83,12.83,0,0,0,1.33-6.17c-0.07-3.49-1.6-4.07-3.11-4.93" transform="translate(-33.03 -18.41)" fill="none" stroke="#349aee" stroke-miterlimit="10" stroke-width="0.68" opacity="0.18"/>
              <path d="M145.08,92.61c-1.62-1.5-5.6-3.83-10.41-5.53,0.09-.21.17-0.45,0.26-0.71a17.24,17.24,0,0,0,.92-6.06c-0.08-3.36-1.35-4.13-2.5-5.08" transform="translate(-33.03 -18.41)" fill="none" stroke="#369bee" stroke-miterlimit="10" stroke-width="0.72" opacity="0.19"/>
              <path d="M145.65,90.19a103.65,103.65,0,0,0-10.44-4.74c0-.21.07-0.45,0.12-0.71a28.83,28.83,0,0,0,.51-6,7.28,7.28,0,0,0-1.89-5.24" transform="translate(-33.03 -18.41)" fill="none" stroke="#389cee" stroke-miterlimit="10" stroke-width="0.75" opacity="0.2"/>
              <path d="M146.16,87.77a78.69,78.69,0,0,1-10.48-4c0-.22,0-0.45,0-0.71,0-1.46.18-3.48,0.1-5.86a12.68,12.68,0,0,0-1.28-5.39" transform="translate(-33.03 -18.41)" fill="none" stroke="#3b9dee" stroke-miterlimit="10" stroke-width="0.79" opacity="0.21"/>
              <path d="M146.61,85.38c-2.11.16-6.31-1.21-10.51-3.18C136,82,136,81.74,135.94,81.48a55.09,55.09,0,0,1-.32-5.75c-0.11-2.94-.6-4.29-0.67-5.54" transform="translate(-33.03 -18.41)" fill="none" stroke="#3d9eee" stroke-miterlimit="10" stroke-width="0.82" opacity="0.22"/>
              <path d="M147.06,82.92c-2.27.71-6.54-.34-10.55-2.4a6.92,6.92,0,0,1-.29-0.72,22.26,22.26,0,0,1-.73-5.65c-0.11-2.81-.35-4.34-0.06-5.69" transform="translate(-33.03 -18.41)" fill="none" stroke="#3fa0ee" stroke-miterlimit="10" stroke-width="0.86" opacity="0.23"/>
              <path d="M147.6,80.44c-2.43,1.26-6.78.54-10.58-1.61a6.34,6.34,0,0,1-.43-0.72,14.3,14.3,0,0,1-1.14-5.54c-0.12-2.67-.11-4.4.54-5.84" transform="translate(-33.03 -18.41)" fill="none" stroke="#41a1ee" stroke-miterlimit="10" stroke-width="0.89" opacity="0.24"/>
              <path d="M148.14,78c-2.59,1.81-7,1.41-10.61-.83a6.55,6.55,0,0,1-.57-0.73A10.89,10.89,0,0,1,135.41,71c-0.13-2.53.14-4.45,1.15-6" transform="translate(-33.03 -18.41)" fill="none" stroke="#44a2ef" stroke-miterlimit="10" stroke-width="0.93" opacity="0.25"/>
              <path d="M148.61,75.56c-2.75,2.36-7.25,2.29-10.65,0a7.22,7.22,0,0,1-.7-0.73,9.11,9.11,0,0,1-2-5.34,8.5,8.5,0,0,1,1.76-6.14" transform="translate(-33.03 -18.41)" fill="none" stroke="#46a3ef" stroke-miterlimit="10" stroke-width="0.96" opacity="0.26"/>
              <path d="M149,73.24A8.15,8.15,0,0,1,137.5,61.72" transform="translate(-33.03 -18.41)" fill="none" stroke="#48a4ef" stroke-miterlimit="10" opacity="0.27"/>
            </g>
            <circle cx="142.63" cy="75.64" r="11.95" fill="url(#partner-gradient)"/>
            <circle cx="117.21" cy="143.23" r="12" fill="url(#partner-gradient-2)"/>
            <path d="M152.27,157.82c0,1.12-.91,2.81-2,2.81s-2-1.69-2-2.81A2,2,0,0,1,152.27,157.82Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M154.46,165.36c0,1.95-2.27,2.24-4.22,2.24s-4.22-.29-4.22-2.24,2.27-3.53,4.22-3.53S154.46,163.41,154.46,165.36Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <circle cx="163.41" cy="112.74" r="8.6" fill="url(#partner-gradient-3)"/>
            <path d="M197.89,128.41c0,0.8-.65,2-1.45,2s-1.45-1.21-1.45-2A1.45,1.45,0,0,1,197.89,128.41Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M199.46,133.81c0,1.4-1.63,1.6-3,1.6s-3-.21-3-1.6,1.63-2.53,3-2.53S199.46,132.42,199.46,133.81Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <circle cx="61.74" cy="24.68" r="10.97" fill="url(#partner-gradient-4)"/>
            <path d="M96.63,39.6c0,1-.83,2.57-1.85,2.57s-1.85-1.54-1.85-2.57A1.85,1.85,0,0,1,96.63,39.6Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M98.63,46.49c0,1.78-2.07,2-3.86,2s-3.86-.27-3.86-2,2.07-3.23,3.86-3.23S98.63,44.71,98.63,46.49Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <circle cx="54.96" cy="54.24" r="7.65" fill="url(#partner-gradient-5)"/>
            <path d="M89.28,70.22C89.28,70.93,88.7,72,88,72s-1.29-1.08-1.29-1.79A1.29,1.29,0,0,1,89.28,70.22Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M90.68,75c0,1.24-1.45,1.43-2.69,1.43S85.3,76.27,85.3,75s1.45-2.25,2.69-2.25S90.68,73.78,90.68,75Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <circle cx="110.26" cy="48.78" r="8.3" fill="url(#partner-gradient-6)"/>
            <path d="M144.87,64.33c0,0.78-.63,1.95-1.4,1.95s-1.4-1.17-1.4-1.95A1.4,1.4,0,0,1,144.87,64.33Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M146.39,69.55c0,1.35-1.57,1.55-2.92,1.55s-2.92-.2-2.92-1.55,1.57-2.44,2.92-2.44S146.39,68.2,146.39,69.55Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <circle cx="83.78" cy="131.52" r="6.06" fill="url(#partner-gradient-7)"/>
            <path d="M118,147.84a1.08,1.08,0,1,1-2.05,0A1,1,0,0,1,118,147.84Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M119.07,151.65c0,1-1.15,1.13-2.13,1.13s-2.13-.15-2.13-1.13A2.17,2.17,0,0,1,119.07,151.65Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <circle cx="4.39" cy="120.11" r="4.39" fill="#acd5f7" opacity="0.5"/>
            <path d="M38.26,137a1,1,0,0,1-.74,1,1,1,0,0,1-.74-1A0.74,0.74,0,0,1,38.26,137Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M39.06,139.77c0,0.71-.83.82-1.54,0.82S36,140.48,36,139.77A1.57,1.57,0,0,1,39.06,139.77Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <g>
              <circle cx="161.38" cy="53.76" r="3.96" fill="#acd5f7" opacity="0.5"/>
              <path d="M195.17,70.81a0.71,0.71,0,1,1-1.34,0A0.67,0.67,0,0,1,195.17,70.81Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
              <path d="M195.89,73.3c0,0.64-.75.74-1.39,0.74s-1.39-.1-1.39-0.74A1.42,1.42,0,0,1,195.89,73.3Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            </g>
            <g>
              <circle cx="98.98" cy="3.96" r="3.96" fill="#acd5f7" opacity="0.5"/>
              <path d="M132.77,21a0.71,0.71,0,1,1-1.34,0A0.67,0.67,0,0,1,132.77,21Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
              <path d="M133.49,23.5c0,0.64-.75.74-1.39,0.74s-1.39-.1-1.39-0.74A1.42,1.42,0,0,1,133.49,23.5Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            </g>
            <g>
              <circle cx="16.6" cy="21.31" r="5.53" fill="#acd5f7" opacity="0.5"/>
              <path d="M50.69,37.82a1.31,1.31,0,0,1-.94,1.3,1.31,1.31,0,0,1-.94-1.3A0.94,0.94,0,0,1,50.69,37.82Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
              <path d="M51.7,41.3c0,0.9-1,1-1.95,1s-1.95-.13-1.95-1A2,2,0,0,1,51.7,41.3Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            </g>
            <g opacity="0.7">
              <circle cx="78.45" cy="48.78" r="4.98" fill="#acd5f7" opacity="0.5"/>
              <path d="M112.44,65.48a0.89,0.89,0,1,1-1.68,0A0.84,0.84,0,0,1,112.44,65.48Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
              <path d="M113.35,68.61c0,0.81-.94.93-1.75,0.93s-1.75-.12-1.75-0.93A1.78,1.78,0,0,1,113.35,68.61Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            </g>
            <g opacity="0.5">
              <circle cx="179.68" cy="86.01" r="5.53" fill="#acd5f7" opacity="0.5"/>
              <path d="M213.76,102.51a1,1,0,1,1-1.87,0A0.94,0.94,0,1,1,213.76,102.51Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
              <path d="M214.78,106c0,0.9-1,1-1.95,1s-1.95-.13-1.95-1A2,2,0,0,1,214.78,106Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            </g>
            <g opacity="0.5">
              <circle cx="58.32" cy="183.07" r="5.53" fill="#acd5f7" opacity="0.5"/>
              <path d="M92.41,199.57a1,1,0,1,1-1.87,0A0.94,0.94,0,0,1,92.41,199.57Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
              <path d="M93.42,203.05c0,0.9-1,1-1.95,1s-1.95-.13-1.95-1A2,2,0,0,1,93.42,203.05Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            </g>
            <g>
              <circle cx="118.56" cy="165.92" r="5.11" fill="#acd5f7" opacity="0.5"/>
              <path d="M152.57,182.57a0.91,0.91,0,1,1-1.73,0A0.86,0.86,0,1,1,152.57,182.57Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
              <path d="M153.5,185.78c0,0.83-1,1-1.8,1s-1.8-.12-1.8-1A1.83,1.83,0,0,1,153.5,185.78Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            </g>
            <circle cx="120.56" cy="108.57" r="6.37" fill="url(#partner-gradient-8)"/>
            <path d="M154.81,124.79a1.13,1.13,0,1,1-2.15,0A1.08,1.08,0,0,1,154.81,124.79Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M156,128.79c0,1-1.21,1.19-2.24,1.19s-2.24-.15-2.24-1.19A2.28,2.28,0,0,1,156,128.79Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <circle cx="22.14" cy="143.21" r="7.46" fill="url(#partner-gradient-9)"/>
            <path d="M56.59,159c0,0.7-.56,1.75-1.26,1.75s-1.26-1.05-1.26-1.75A1.26,1.26,0,0,1,56.59,159Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M58,163.74c0,1.21-1.41,1.39-2.63,1.39s-2.63-.18-2.63-1.39,1.41-2.2,2.63-2.2S58,162.53,58,163.74Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <circle cx="24.69" cy="65.36" r="15.11" fill="url(#partner-gradient-10)"/>
            <path d="M60.27,79c0,1.41-1.14,3.54-2.55,3.54S55.17,80.37,55.17,79A2.55,2.55,0,0,1,60.27,79Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M63,88.46c0,2.45-2.86,2.82-5.31,2.82s-5.31-.37-5.31-2.82S55.26,84,57.72,84,63,86,63,88.46Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <circle cx="144.6" cy="34.56" r="8.36" fill="url(#partner-gradient-11)"/>
            <path d="M179,50.31c0,0.78-.63,2-1.41,2s-1.41-1.18-1.41-2A1.41,1.41,0,0,1,179,50.31Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M180.57,55.57c0,1.36-1.58,1.56-2.94,1.56s-2.94-.2-2.94-1.56,1.58-2.46,2.94-2.46S180.57,54.21,180.57,55.57Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M178,89.67c0,1.27-1,3.18-2.29,3.18s-2.29-1.91-2.29-3.18A2.29,2.29,0,0,1,178,89.67Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M180.43,98.19c0,2.2-2.57,2.53-4.77,2.53s-4.77-.33-4.77-2.53,2.57-4,4.77-4S180.43,96,180.43,98.19Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <g>
              <path d="M137.65,110.83c-3.62,3.54-10.62,5.54-13.44,5.54-3.88,0-10.69,1-10.69-8.27,0-6.86,1.92-7.32,8.61-8.3-4-1.32-4.8-5.9-4.8-9.83,0-2.58,3.15.1,5-1.48" transform="translate(-33.03 -18.41)" fill="none" stroke="#349aed" stroke-miterlimit="10" stroke-width="0.25" opacity="0.2"/>
              <path d="M120.06,90.59c-1.7,1.47-4.67-1.12-4.62,1.32,0.08,3.71.93,8.07,4.88,9.35-6.29.95-8,1.44-7.93,8.08,0.1,9,6.67,8.13,10.37,8.28,2.7,0.11,9.34-1.67,12.71-5" transform="translate(-33.03 -18.41)" fill="none" stroke="#399ded" stroke-miterlimit="10" stroke-width="0.27" opacity="0.21"/>
              <path d="M117.84,92.66c-1.58,1.36-4.39-1.14-4.29,1.17,0.15,3.49,1.08,7.64,5,8.86-5.88.92-7.42,1.43-7.25,7.87,0.21,8.67,6.52,8,10.06,8.3,2.57,0.22,8.86-1.33,12-4.38" transform="translate(-33.03 -18.41)" fill="none" stroke="#3e9fee" stroke-miterlimit="10" stroke-width="0.29" opacity="0.23"/>
              <path d="M115.63,94.73c-1.47,1.26-4.1-1.16-4,1,0.23,3.28,1.24,7.2,5,8.38-5.48.89-6.81,1.43-6.57,7.65,0.33,8.37,6.38,7.85,9.74,8.31,2.45,0.33,8.38-1,11.24-3.79" transform="translate(-33.03 -18.41)" fill="none" stroke="#44a2ee" stroke-miterlimit="10" stroke-width="0.32" opacity="0.24"/>
              <path d="M113.41,96.79c-1.35,1.16-3.82-1.17-3.62.86,0.31,3.06,1.4,6.76,5.12,7.89-5.08.86-6.21,1.43-5.89,7.44,0.43,8.07,6.25,7.71,9.42,8.32,2.33,0.45,7.9-.66,10.51-3.21" transform="translate(-33.03 -18.41)" fill="none" stroke="#49a4ef" stroke-miterlimit="10" stroke-width="0.34" opacity="0.25"/>
              <path d="M111.21,98.87c-1.24,1.05-3.54-1.19-3.28.71,0.39,2.85,1.55,6.33,5.2,7.41-4.68.82-5.61,1.42-5.21,7.22,0.54,7.77,6.11,7.58,9.11,8.34,2.21,0.56,7.42-.33,9.78-2.63" transform="translate(-33.03 -18.41)" fill="none" stroke="#4ea7ef" stroke-miterlimit="10" stroke-width="0.36" opacity="0.27"/>
              <path d="M109.33,100.95c-1.12.95-3.25-1.21-2.94,0.56,0.46,2.63,1.71,5.89,5.28,6.93-4.27.79-5,1.42-4.53,7,0.65,7.46,6,7.44,8.79,8.35,2.09,0.67,6.94,0,9-2" transform="translate(-33.03 -18.41)" fill="none" stroke="#53a9f0" stroke-miterlimit="10" stroke-width="0.38" opacity="0.28"/>
              <path d="M107.49,103c-1,.84-3-1.22-2.61.4,0.54,2.42,1.87,5.45,5.36,6.44-3.87.76-4.42,1.42-3.85,6.79,0.76,7.16,5.84,7.31,8.47,8.36,2,0.79,6.46.34,8.32-1.46" transform="translate(-33.03 -18.41)" fill="none" stroke="#59acf0" stroke-miterlimit="10" stroke-width="0.4" opacity="0.29"/>
              <path d="M105.66,105c-0.89.74-2.69-1.23-2.27,0.25a7.92,7.92,0,0,0,5.44,6c-3.47.73-3.82,1.41-3.17,6.58,0.87,6.86,5.71,7.18,8.15,8.38,1.86,0.91,6,.67,7.58-0.88" transform="translate(-33.03 -18.41)" fill="none" stroke="#5eaff0" stroke-miterlimit="10" stroke-width="0.42" opacity="0.3"/>
              <path d="M103.82,107.07c-0.78.63-2.4-1.24-1.94,0.1a8,8,0,0,0,5.52,5.47c-3.07.7-3.22,1.41-2.49,6.36,1,6.56,5.58,7.06,7.84,8.39,1.74,1,5.5,1,6.85-.29" transform="translate(-33.03 -18.41)" fill="none" stroke="#63b1f1" stroke-miterlimit="10" stroke-width="0.45" opacity="0.32"/>
              <path d="M102,109.06c-0.66.53-2.12-1.25-1.6-.06a8.26,8.26,0,0,0,5.6,5c-2.66.67-2.62,1.41-1.81,6.15,1.08,6.26,5.45,6.94,7.52,8.4,1.63,1.15,5,1.34,6.12.29" transform="translate(-33.03 -18.41)" fill="none" stroke="#68b4f1" stroke-miterlimit="10" stroke-width="0.47" opacity="0.33"/>
              <path d="M100.16,111c-0.55.42-1.83-1.26-1.27-.21a8.69,8.69,0,0,0,5.68,4.51c-2.26.64-2,1.4-1.13,5.93,1.18,6,5.32,6.82,7.2,8.41,1.51,1.28,4.54,1.68,5.39.87" transform="translate(-33.03 -18.41)" fill="none" stroke="#6db6f2" stroke-miterlimit="10" stroke-width="0.49" opacity="0.34"/>
              <path d="M98.34,113c-0.43.32-1.54-1.27-.93-0.36a9.41,9.41,0,0,0,5.76,4c-1.86.61-1.43,1.4-.45,5.72,1.29,5.65,5.18,6.71,6.89,8.43,1.39,1.41,4.06,2,4.65,1.46" transform="translate(-33.03 -18.41)" fill="none" stroke="#73b9f2" stroke-miterlimit="10" stroke-width="0.51" opacity="0.36"/>
              <path d="M96.51,114.87c-0.31.21-1.24-1.27-.6-0.51a10.62,10.62,0,0,0,5.84,3.54c-1.46.57-.83,1.39,0.23,5.5,1.39,5.35,5,6.6,6.57,8.44,1.27,1.54,3.58,2.35,3.92,2" transform="translate(-33.03 -18.41)" fill="none" stroke="#78bbf3" stroke-miterlimit="10" stroke-width="0.53" opacity="0.37"/>
              <path d="M94.7,116.73c-0.2.11-.94-1.28-0.26-0.67a12.73,12.73,0,0,0,5.92,3.06c-1.05.54-.24,1.39,0.91,5.28,1.49,5,4.9,6.49,6.25,8.45a7.66,7.66,0,0,0,3.19,2.62" transform="translate(-33.03 -18.41)" fill="none" stroke="#7dbef3" stroke-miterlimit="10" stroke-width="0.55" opacity="0.38"/>
              <path d="M92.89,118.57c-0.08,0-.64-1.29.08-0.82a16.77,16.77,0,0,0,6,2.57c-0.65.51,0.36,1.38,1.6,5.07,1.6,4.74,4.76,6.38,5.94,8.47,1,1.81,2.62,3,2.46,3.21" transform="translate(-33.03 -18.41)" fill="none" stroke="#82c0f4" stroke-miterlimit="10" stroke-width="0.58" opacity="0.4"/>
              <path d="M91.06,120.41c0-.1-0.33-1.3.41-1a26.45,26.45,0,0,0,6.08,2.09c-0.25.48,0.95,1.38,2.28,4.85,1.7,4.44,4.61,6.28,5.62,8.48,0.89,1.95,2.14,3.35,1.73,3.79" transform="translate(-33.03 -18.41)" fill="none" stroke="#87c3f4" stroke-miterlimit="10" stroke-width="0.6" opacity="0.41"/>
              <path d="M89.28,122.22c0.15-.21,0-1.32.75-1.13,1.49,0.39,3.44,1.09,6.16,1.6a18.68,18.68,0,0,1,3,4.64c1.8,4.14,4.45,6.17,5.3,8.49,0.76,2.08,1.66,3.68,1,4.37" transform="translate(-33.03 -18.41)" fill="none" stroke="#8dc6f4" stroke-miterlimit="10" stroke-width="0.62" opacity="0.42"/>
              <path d="M87.48,124.13c0.26-.31.3-1.2,1.08-1.28,1.6-.16,3.6.65,6.24,1.12a10.46,10.46,0,0,1,3.64,4.42c1.89,3.84,4.3,6.06,5,8.51,0.62,2.22,1.18,4,.26,5" transform="translate(-33.03 -18.41)" fill="none" stroke="#92c8f5" stroke-miterlimit="10" stroke-width="0.64" opacity="0.43"/>
              <path d="M85.61,126c0.38-.42.61-1.27,1.42-1.43,1.68-.35,3.75.22,6.32,0.64a8.84,8.84,0,0,1,4.32,4.21c2,3.54,4.14,6,4.67,8.52,0.48,2.35.7,4.35-.47,5.54" transform="translate(-33.03 -18.41)" fill="none" stroke="#97cbf5" stroke-miterlimit="10" stroke-width="0.66" opacity="0.45"/>
              <path d="M83.68,127.95c0.49-.52.9-1.42,1.75-1.59a19.36,19.36,0,0,1,6.41.15,8.67,8.67,0,0,1,5,4c2.08,3.24,4,5.84,4.35,8.53,0.34,2.48.22,4.69-1.2,6.12" transform="translate(-33.03 -18.41)" fill="none" stroke="#9ccdf6" stroke-miterlimit="10" stroke-width="0.68" opacity="0.46"/>
              <path d="M81.7,130a5.57,5.57,0,0,1,2.09-1.74,14.88,14.88,0,0,1,6.49-.33,9.16,9.16,0,0,1,5.68,3.78c2.18,2.94,3.82,5.72,4,8.55,0.2,2.61-.26,5-1.94,6.7" transform="translate(-33.03 -18.41)" fill="none" stroke="#a2d0f6" stroke-miterlimit="10" stroke-width="0.71" opacity="0.47"/>
              <path d="M79.68,132a8.08,8.08,0,0,1,2.42-1.89,12.73,12.73,0,0,1,6.57-.82A10.14,10.14,0,0,1,95,132.89a13.9,13.9,0,0,1,3.72,8.56,9.78,9.78,0,0,1-2.67,7.29" transform="translate(-33.03 -18.41)" fill="none" stroke="#a7d2f7" stroke-miterlimit="10" stroke-width="0.73" opacity="0.49"/>
              <path d="M77.63,134.12a11.63,11.63,0,0,1,16.44,16.44" transform="translate(-33.03 -18.41)" fill="none" stroke="#acd5f7" stroke-miterlimit="10" stroke-width="0.75" opacity="0.5"/>
            </g>
            <circle cx="86.94" cy="158.33" r="8.93" fill="url(#partner-gradient-12)"/>
            <path d="M121.68,173.47c0,0.95-.77,2.37-1.71,2.37s-1.71-1.43-1.71-2.37A1.71,1.71,0,1,1,121.68,173.47Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M123.53,179.84c0,1.65-1.92,1.89-3.56,1.89s-3.56-.25-3.56-1.89,1.92-3,3.56-3S123.53,178.19,123.53,179.84Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <circle cx="52.62" cy="124.13" r="12.2" fill="url(#partner-gradient-13)"/>
            <path d="M88,138.07c0,1.29-1,3.24-2.34,3.24s-2.34-2-2.34-3.24A2.34,2.34,0,1,1,88,138.07Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M90.52,146.77c0,2.25-2.62,2.59-4.87,2.59s-4.87-.34-4.87-2.59,2.62-4.07,4.87-4.07S90.52,144.52,90.52,146.77Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <ellipse cx="27.24" cy="104.47" rx="8.14" ry="8.27" fill="url(#partner-gradient-14)"/>
            <path d="M61.65,120.25c0,0.77-.62,1.94-1.37,1.94S58.9,121,58.9,120.25A1.37,1.37,0,1,1,61.65,120.25Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <path d="M63.13,125.44c0,1.34-1.54,1.54-2.86,1.54s-2.86-.2-2.86-1.54S58.95,123,60.27,123,63.13,124.1,63.13,125.44Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            <polygon points="91.15 88.66 91.11 88.68 91.11 88.64 91.15 88.66" fill="#fff"/>
            <circle cx="91.36" cy="83.59" r="15.62" fill="#0a85ea"/>
            <g>
              <path d="M116.71,103.95a1.94,1.94,0,0,0,.17.67,1.71,1.71,0,0,0,.38.54,1.75,1.75,0,0,0,.57.36,2,2,0,0,0,.73.13,2,2,0,0,0,.68-0.11,1.62,1.62,0,0,0,.55-0.33,1.55,1.55,0,0,0,.37-0.52,1.7,1.7,0,0,0,.13-0.69,1.75,1.75,0,0,0-.15-0.74,1.53,1.53,0,0,0-.39-0.53,1.68,1.68,0,0,0-.56-0.32,2.18,2.18,0,0,0-1.56.08,1.87,1.87,0,0,0-.64.47l-0.36-.13-0.52-.18-0.52-.18-0.34-.13,1.15-4.82h5.25v1.61h-4l-0.55,2.27a2,2,0,0,1,.8-0.45,3.3,3.3,0,0,1,1-.15,3.83,3.83,0,0,1,1.31.21,2.93,2.93,0,0,1,1,.62,2.78,2.78,0,0,1,.67,1,3.53,3.53,0,0,1,.24,1.34,3.23,3.23,0,0,1-.25,1.26,3.13,3.13,0,0,1-.71,1,3.36,3.36,0,0,1-1.13.71,4.44,4.44,0,0,1-2.92,0,3.58,3.58,0,0,1-1.11-.64,3.14,3.14,0,0,1-.74-0.92,2.85,2.85,0,0,1-.33-1.08Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
              <path d="M127.53,99.56a2.09,2.09,0,0,1-.18.87,2.24,2.24,0,0,1-.48.7,2.11,2.11,0,0,1-.71.46,2.34,2.34,0,0,1-.87.16,2.21,2.21,0,0,1-2-1.32,2.12,2.12,0,0,1-.17-0.87,2.08,2.08,0,0,1,.18-0.86,2.28,2.28,0,0,1,.48-0.7,2.24,2.24,0,0,1,3.13,0,2.26,2.26,0,0,1,.48.7A2.06,2.06,0,0,1,127.53,99.56Zm-3.13,0a0.92,0.92,0,0,0,.25.68,0.87,0.87,0,0,0,.64.26,0.82,0.82,0,0,0,.63-0.26,1,1,0,0,0,.24-0.68,0.94,0.94,0,0,0-.24-0.66,0.82,0.82,0,0,0-.63-0.26,0.86,0.86,0,0,0-.64.26A0.91,0.91,0,0,0,124.41,99.56Zm0.07,7.47,6.12-9.51h1.58L126.06,107h-1.58Zm4.64-2a2.06,2.06,0,0,1,.18-0.86,2.21,2.21,0,0,1,1.19-1.16,2.22,2.22,0,0,1,.86-0.17,2.27,2.27,0,0,1,.87.17,2.22,2.22,0,0,1,.71.46,2.26,2.26,0,0,1,.48.7,2.06,2.06,0,0,1,.18.86,2.1,2.1,0,0,1-.18.87,2.17,2.17,0,0,1-.48.69,2.31,2.31,0,0,1-2.44.46,2.18,2.18,0,0,1-.71-0.46,2.16,2.16,0,0,1-.48-0.7A2.14,2.14,0,0,1,129.12,105Zm3.11,0a0.92,0.92,0,0,0-.25-0.67,0.92,0.92,0,0,0-1.27,0,0.91,0.91,0,0,0-.25.67,0.92,0.92,0,0,0,.25.68,0.85,0.85,0,0,0,.63.25,0.84,0.84,0,0,0,.64-0.26A0.94,0.94,0,0,0,132.23,105Z" transform="translate(-33.03 -18.41)" fill="#fff"/>
            </g>
          </svg>
        </div>
        <div class="col-md-7 col-sm-7 col-xs-6">
          <h3>Affiliate Program</h3>
          <p>Take advantage of our Invite a Friend Program. AstroFX introduces a new type of affiliate program oriented at our traders who are willing to invite their friends and get rewarded for that. It has never been as simple as now. You don't have to make deposits in order to refer your friends anymore.</p>
          		  <a onclick="openModal('register-modal')"class="btn red-gradient">Start Earning</a> 
		  		  </div>
      </div>
    </div>
  </div>
         </header>

<div class="marketing-tools" style="background:#fff;">
  <div class="container">
    <div class="row">
      <div class="col-md-2 col-sm-2 col-xs-2">
        <div class="marketing-tools__icon">
          <svg viewBox="0 0 381 396.26">
            <use xlink:href="#markettingTools"></use>
          </svg>
        </div>
      </div>
      <div class="col-md-9 col-sm-10 col-xs-10">
        <h2>Take advantage of our Invite a Friend Program </h2>
        <p>Share your referral link from your Personal Area and start earning today.</p>
        <ul>
          <li>
            <svg viewBox="0 0 30.58 30.58">
              <use xlink:href="#externalLink"></use>
            </svg>
            <span>
						<a onclick="openModal('register-modal')">Personal Referral Link</a>
						</span> </li>
          <li>
            <svg viewBox="0 0 45.65 29.19">
              <use xlink:href="#adsBanners"></use>
            </svg>
            <span>
						<a onclick="openModal('register-modal')">Marketing Banners</a>
						</span> </li>
          <!--<li>
            <svg viewBox="0 0 47.7 28.63">
              <use xlink:href="#usersOnline"></use>
            </svg>
            <span>Social Media Sharing</span> </li>-->
        </ul>
      </div>
    </div>
  </div>
</div>
<footer>   <div class="ready-to-start">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-sm-8 col-xs-7">
          <h2>Ready to get started?</h2>
                    <p>You are just few steps away from your first income. Make a new investment today. </p>
           </div>
        <div class="col-md-4 col-sm-4 col-xs-5 text-center"> 
				<a onclick="openModal('register-modal')" class="btn btn--blue" style="cursor: pointer">Create New Account</a> 
				</div>
      </div>
    </div>
  </div>