<div class="col-lg-2 col-md-2 col-xs-6"> <a href="./" class="header-logo"> <div><img class="logo-image" src="images/logo.png" alt="AstroFX"></div> <span>AstroFX</span> </a> </div>
        <div class="col-lg-7 col-md-7 col-sm-8 hidden-xs">
          <nav>
             <ul>
                                <li><a href="?a=cust&amp;page=about">About Us</a></li>
                                <!--<li><a href="?a=cust&amp;page=guide">How It Works</a></li>-->
                                <li><a href="?a=cust&amp;page=testimonials">Testimonials</a></li>
                                <li><a href="?a=cust&amp;page=partnership">Invite a Friend</a></li>
                                <!--
              <li><a href="?a=news">Blog</a></li> -->
                                <li><a href="?page=support">Contact Us</a></li>
                            </ul>
          </nav>
        </div>