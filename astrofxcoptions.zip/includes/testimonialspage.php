
<header style="height: -440px">
  <div class="header-menu">
    <div class="container">
     


<div class="row">
        <?php
                                include_once('includes/nav.php');
                                include_once('includes/nav2.php');
                            ?>
      </div>
    </div>
  </div>
        <div class="services-intro">
    <svg class="bg-svg" viewBox="0 0 1460.5 528.85">
      <defs>
        <linearGradient id="linear-gradient" y1="525.67" x2="0" y2="317.64" gradientUnits="userSpaceOnUse">
          <stop offset="0.06" stop-color="#a2d9f2" stop-opacity="0.1" />
          <stop offset="0.73" stop-color="#a2d9f2" stop-opacity="0.5" />
          <stop offset="0.85" stop-color="#a2d9f2" stop-opacity="0.51" />
          <stop offset="0.89" stop-color="#a2d9f2" stop-opacity="0.54" />
          <stop offset="0.92" stop-color="#a2d9f2" stop-opacity="0.58" />
          <stop offset="0.94" stop-color="#a2d9f2" stop-opacity="0.65" />
          <stop offset="0.96" stop-color="#a2d9f2" stop-opacity="0.75" />
          <stop offset="0.98" stop-color="#a2d9f2" stop-opacity="0.86" />
          <stop offset="1" stop-color="#a2d9f2" stop-opacity="0.99" />
          <stop offset="1" stop-color="#a2d9f2" />
        </linearGradient>
        <linearGradient id="linear-gradient-2" x1="6.85" y1="526.85" x2="6.85" y2="318.13" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-3" x1="13.29" y1="528.46" x2="13.29" y2="318.45" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-4" x1="20.14" y1="530.5" x2="20.14" y2="318.39" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-5" x1="33.86" y1="532.4" x2="33.86" y2="316.51" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-6" x1="40.28" y1="528.87" x2="40.28" y2="315.04" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-7" x1="47.14" y1="524.55" x2="47.14" y2="313.21" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-8" x1="54" y1="525.18" x2="54" y2="311.23" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-9" x1="67.28" y1="548.43" x2="67.28" y2="315.92" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-10" x1="74.14" y1="559.98" x2="74.14" y2="319.2" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-11" x1="87.87" y1="573.93" x2="87.87" y2="301.9" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-12" x1="94.27" y1="580.24" x2="94.27" y2="286.37" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-13" x1="101.13" y1="586.74" x2="101.13" y2="271.63" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-14" x1="114.87" y1="603.16" x2="114.87" y2="246.21" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-15" x1="128.13" y1="635.57" x2="128.13" y2="250.46" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-16" x1="141.87" y1="642.25" x2="141.87" y2="247.22" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-17" x1="148.01" y1="639.25" x2="148.01" y2="235.94" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-18" x1="162" y1="644.38" x2="162" y2="216.89" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-19" x1="168.86" y1="650.5" x2="168.86" y2="217.5" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-20" x1="175.27" y1="656.61" x2="175.27" y2="224.03" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-21" x1="182.14" y1="663.94" x2="182.14" y2="234.24" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-22" x1="195.86" y1="684.36" x2="195.86" y2="244.8" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-23" x1="202.27" y1="688.79" x2="202.27" y2="239.42" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-24" x1="209.13" y1="688.25" x2="209.13" y2="230.07" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-25" x1="216" y1="687.82" x2="216" y2="223.26" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-26" x1="228.99" y1="692.13" x2="228.99" y2="212.47" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-27" x1="236.13" y1="693.65" x2="236.13" y2="205.19" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-28" x1="243" y1="694.17" x2="243" y2="202.61" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-29" x1="263.13" y1="690.49" x2="263.13" y2="230.21" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-30" x1="270" y1="688.02" x2="270" y2="235.54" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-31" x1="276.87" y1="684.41" x2="276.87" y2="238.81" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-32" x1="290.13" y1="665.94" x2="290.13" y2="236.93" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-33" x1="296.99" y1="656.42" x2="296.99" y2="233.49" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-34" x1="303.87" y1="653.62" x2="303.87" y2="235.76" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-35" x1="310.46" y1="656.34" x2="310.46" y2="246.68" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-36" x1="317.25" y1="660.46" x2="317.25" y2="257.99" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-37" x1="336.99" y1="658.71" x2="336.99" y2="273.51" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-38" x1="344.13" y1="656.79" x2="344.13" y2="274.13" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-39" x1="351" y1="655.39" x2="351" y2="273.67" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-40" x1="357.87" y1="657.06" x2="357.87" y2="274.55" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-41" x1="364.1" y1="663.27" x2="364.1" y2="279.66" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-42" x1="378" y1="676.55" x2="378" y2="302.48" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-43" x1="384.86" y1="670.63" x2="384.86" y2="310.56" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-44" x1="390.99" y1="660.51" x2="390.99" y2="316.26" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-45" x1="398.14" y1="652.67" x2="398.14" y2="321.71" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-46" x1="405" y1="648.84" x2="405" y2="326.73" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-47" x1="418" y1="646.61" x2="418" y2="337.6" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-48" x1="425.14" y1="644.51" x2="425.14" y2="343.98" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-49" x1="432" y1="638.49" x2="432" y2="350.67" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-50" x1="438.86" y1="629.02" x2="438.86" y2="357.57" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-51" x1="445" y1="619.69" x2="445" y2="364.55" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-52" x1="452.14" y1="618.02" x2="452.14" y2="371.51" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-53" x1="465.86" y1="630.88" x2="465.86" y2="384.86" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-54" x1="471.82" y1="633.99" x2="471.82" y2="388.21" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-55" x1="479.15" y1="633.55" x2="479.15" y2="386.69" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-56" x1="492.86" y1="630.84" x2="492.86" y2="380.18" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-57" x1="499.18" y1="629.64" x2="499.18" y2="391.24" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-58" x1="506.15" y1="629.02" x2="506.15" y2="405.93" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-59" x1="525.99" y1="660.02" x2="525.99" y2="415.34" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-60" x1="533.14" y1="678.49" x2="533.14" y2="406.91" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-61" x1="540" y1="679.77" x2="540" y2="403.13" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-62" x1="546.87" y1="663.36" x2="546.87" y2="409.51" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-63" x1="553.81" y1="644.69" x2="553.81" y2="420.76" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-64" x1="560.18" y1="635.16" x2="560.18" y2="428" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-65" x1="580.39" y1="629.4" x2="580.39" y2="415.36" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-66" x1="587.16" y1="632.4" x2="587.16" y2="402.18" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-67" x1="593.97" y1="637.42" x2="593.97" y2="398.94" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-68" x1="600.87" y1="641.46" x2="600.87" y2="405.74" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-69" x1="607.22" y1="642.43" x2="607.22" y2="408.39" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-70" x1="621.07" y1="641.38" x2="621.07" y2="401.4" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-71" x1="627.87" y1="640.65" x2="627.87" y2="400.47" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-72" x1="641.21" y1="636.39" x2="641.21" y2="401.85" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-73" x1="654.86" y1="627.91" x2="654.86" y2="396.22" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-74" x1="661.18" y1="623.66" x2="661.18" y2="392.58" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-75" x1="668.19" y1="620.7" x2="668.19" y2="402.99" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-76" x1="681.86" y1="618.82" x2="681.86" y2="383.84" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-77" x1="702.03" y1="641.5" x2="702.03" y2="374.29" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-78" x1="708.87" y1="654.02" x2="708.87" y2="372.04" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-79" x1="722.15" y1="641.59" x2="722.15" y2="368.27" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-80" x1="729.01" y1="636.24" x2="729.01" y2="366.46" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-81" x1="735.87" y1="635.57" x2="735.87" y2="362.61" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-82" x1="742.4" y1="638.03" x2="742.4" y2="355.49" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-83" x1="749.13" y1="640.67" x2="749.13" y2="346.36" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-84" x1="755.99" y1="643.8" x2="755.99" y2="340.99" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-85" x1="769.27" y1="656.66" x2="769.27" y2="350.88" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-86" x1="776.13" y1="665.03" x2="776.13" y2="356.52" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-87" x1="796.27" y1="666.44" x2="796.27" y2="358.1" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-88" x1="803.14" y1="668.2" x2="803.14" y2="357.6" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-89" x1="823.27" y1="654.04" x2="823.27" y2="356.81" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-90" x1="830.13" y1="662.47" x2="830.13" y2="356.88" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-91" x1="836.96" y1="673.76" x2="836.96" y2="354.9" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-92" x1="843.83" y1="685.42" x2="843.83" y2="349.41" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-93" x1="850.24" y1="694.9" x2="850.24" y2="342.04" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-94" x1="863.97" y1="704.4" x2="863.97" y2="344.96" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-95" x1="870.84" y1="703.45" x2="870.84" y2="355.92" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-96" x1="877.04" y1="699.6" x2="877.04" y2="364.52" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-97" x1="884.12" y1="695.34" x2="884.12" y2="369.63" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-98" x1="890.89" y1="693.89" x2="890.89" y2="372.72" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-99" x1="904.21" y1="703.58" x2="904.21" y2="378.9" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-100" x1="911.01" y1="701" x2="911.01" y2="382.02" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-101" x1="917.87" y1="698.82" x2="917.87" y2="385.08" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-102" x1="924.84" y1="702.02" x2="924.84" y2="387.96" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-103" x1="931.02" y1="708.3" x2="931.02" y2="390.49" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-104" x1="938.15" y1="699.36" x2="938.15" y2="392.59" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-105" x1="951.87" y1="686.13" x2="951.87" y2="395.46" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-106" x1="958.26" y1="679.76" x2="958.26" y2="396.33" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-107" x1="965.13" y1="679.02" x2="965.13" y2="396.85" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-108" x1="972" y1="684" x2="972" y2="396.98" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-109" x1="985.01" y1="699.81" x2="985.01" y2="396" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-110" x1="992.16" y1="666.77" x2="992.16" y2="394.74" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-111" x1="999.03" y1="679" x2="999.03" y2="392.82" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-112" x1="1005.87" y1="686.59" x2="1005.87" y2="390.16" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-113" x1="1019.19" y1="702.62" x2="1019.19" y2="381.12" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-114" x1="1039.17" y1="718.1" x2="1039.17" y2="346.19" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-115" x1="1052.95" y1="703.65" x2="1052.95" y2="344.1" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-116" x1="1059.83" y1="698.55" x2="1059.83" y2="341.63" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-117" x1="1066.33" y1="696.13" x2="1066.33" y2="335.41" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-118" x1="1086.87" y1="694.66" x2="1086.87" y2="311.93" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-119" x1="1093.04" y1="695.18" x2="1093.04" y2="304.63" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-120" x1="1107.05" y1="696.86" x2="1107.05" y2="291.63" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-121" x1="1113.87" y1="697.72" x2="1113.87" y2="288.03" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-122" x1="1120.04" y1="698.49" x2="1120.04" y2="285.84" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-123" x1="1140.87" y1="701.74" x2="1140.87" y2="269.63" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-124" x1="1147.02" y1="705.09" x2="1147.02" y2="262" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-125" x1="1154.15" y1="707.87" x2="1154.15" y2="257.98" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-126" x1="1167.86" y1="701.41" x2="1167.86" y2="253.81" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-127" x1="1173.99" y1="696.07" x2="1173.99" y2="250.08" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-128" x1="1181.13" y1="692.15" x2="1181.13" y2="242.89" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-129" x1="1187.99" y1="689.14" x2="1187.99" y2="234.16" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-130" x1="1201.28" y1="682.24" x2="1201.28" y2="238.14" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-131" x1="1208.14" y1="678.31" x2="1208.14" y2="250.48" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-132" x1="1214.98" y1="674.13" x2="1214.98" y2="260.72" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-133" x1="1221.83" y1="669.75" x2="1221.83" y2="267.21" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-134" x1="1235.14" y1="659.37" x2="1235.14" y2="275.92" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-135" x1="1241.96" y1="649.8" x2="1241.96" y2="280.78" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-136" x1="1255.28" y1="625.64" x2="1255.28" y2="291.45" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-137" x1="1262.14" y1="622.92" x2="1262.14" y2="297.15" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-138" x1="1275.8" y1="631.64" x2="1275.8" y2="309.95" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-139" x1="1281.82" y1="632.88" x2="1281.82" y2="320.43" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-140" x1="1289.13" y1="631.26" x2="1289.13" y2="331.67" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-141" x1="1295.94" y1="629.29" x2="1295.94" y2="338.28" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-142" x1="1316.14" y1="607.78" x2="1316.14" y2="343.26" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-143" x1="1322.94" y1="604.44" x2="1322.94" y2="346.59" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-144" x1="1336.28" y1="620.72" x2="1336.28" y2="353.79" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-145" x1="1343.14" y1="627.92" x2="1343.14" y2="356.53" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-146" x1="1349.96" y1="631.43" x2="1349.96" y2="358.62" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-147" x1="1363.29" y1="634.47" x2="1363.29" y2="360.61" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-148" x1="1370.15" y1="636.16" x2="1370.15" y2="357.53" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-149" x1="1383.85" y1="633.64" x2="1383.85" y2="336.96" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-150" x1="1390.29" y1="627.2" x2="1390.29" y2="329.95" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-151" x1="1410.86" y1="634.53" x2="1410.86" y2="347.39" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-152" x1="1417.29" y1="644.35" x2="1417.29" y2="347.76" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-153" x1="1424.14" y1="650.75" x2="1424.14" y2="344.92" xlink:href="#linear-gradient"
                    />
        <linearGradient id="linear-gradient-154" x1="1431" y1="656.4" x2="1431" y2="341.76" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-155" x1="1444.3" y1="678.25" x2="1444.3" y2="338.34" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-156" x1="1451.15" y1="685.8" x2="1451.15" y2="341.68" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-157" x1="1458" y1="681.67" x2="1458" y2="345.88" xlink:href="#linear-gradient" />
        <linearGradient id="linear-gradient-158" x1="244.25" y1="10" x2="244.25" gradientUnits="userSpaceOnUse">
          <stop offset="0" stop-color="#44b4cc" stop-opacity="0" />
          <stop offset="1" stop-color="#44b4cc" />
        </linearGradient>
        <linearGradient id="linear-gradient-159" x1="102.27" y1="75.4" x2="102.27" y2="65.4" xlink:href="#linear-gradient-158" />
        <linearGradient id="linear-gradient-160" x1="365.75" y1="88.63" x2="365.75" y2="78.63" xlink:href="#linear-gradient-158"
                    />
        <linearGradient id="linear-gradient-161" x1="541.25" y1="208.24" x2="541.25" y2="198.24" xlink:href="#linear-gradient-158"
                    />
        <linearGradient id="linear-gradient-162" x1="1040.42" y1="153.96" x2="1040.42" y2="143.96" xlink:href="#linear-gradient-158"
                    />
        <linearGradient id="linear-gradient-163" x1="1189.25" y1="37.29" x2="1189.25" y2="27.29" xlink:href="#linear-gradient-158"
                    />
        <linearGradient id="linear-gradient-164" x1="1391.75" y1="128.93" x2="1391.75" y2="118.93" xlink:href="#linear-gradient-158"
                    />
      </defs>
      <path d="M0,318.89V524.42" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient)" />
      <path d="M6.75,319.38q.06,13.15.11,26.32.21,90.45-.11,179.9" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round"
                    stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-2)" />
      <path d="M13.5,319.7c0,1.51,0,3,0,4.52C13,336,13,349,13.23,360.62l0,7c-.19,53.27-.14,106.37.3,159.63" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-3)" />
      <path d="M20.25,319.64C20,338,20,356,20.09,374q0,3.56,0,7.09-.1,74.09.17,148.17" transform="translate(1.25 -189.25)" fill="none"
                    stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-4)" />
      <path d="M33.75,317.76C34,340,34,363,33.93,385.45q0,3.41,0,6.81c0,28.16,0,56.34,0,84.37q0,3.24,0,6.46C34,499,34,515,33.75,531.15"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-5)" />
      <path d="M40.5,316.29C40,339,40,363,40.15,385.56q0,3.48,0,6.94-.08,39.72,0,79.23,0,3.3,0,6.59C40,495,40,511,40.5,527.62"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-6)" />
      <path d="M47.25,314.46C47,337,47,359,47.08,381.79q0,3.34,0,6.67,0,41.55,0,83.4c0,2.32,0,4.64,0,6.91C47,494,47,508,47.25,523.3"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-7)" />
      <path d="M54,312.48V523.93" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-8)" />
      <path d="M67.5,317.17c-.06,2.11-.12,4.23-.16,6.36C67,339,67,354,67.13,368.75c0,2.24,0,4.53,0,6.83-.06,32.15-.08,64.47,0,96.79,0,2.31,0,4.62,0,6.91C67,502,67,524,67.5,547.18"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-9)" />
      <path d="M74.25,320.45C74,339,74,357,74.06,376.24q0,3.54,0,7.08c0,31.78,0,63.76,0,95.69v6.82C74,510,74,535,74.25,558.73"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-10)" />
      <path d="M87.75,303.15C88,326,88,350,88,372.88v6.71c0,64.81,0,128.63-.22,193.09" transform="translate(1.25 -189.25)" fill="none"
                    stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-11)" />
      <path d="M94.5,287.62C94,315,94,342,94.1,368.88c0,1.66,0,3.33,0,5s0,3.35,0,5C94,446,94,512,94.5,579" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-12)" />
      <path d="M101.25,272.88C101,304,101,335,101.05,366c0,1.73,0,3.47,0,5.2s0,3.46,0,5.19c0,69.6,0,138.6.22,209.09" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-13)" />
      <path d="M114.75,247.46c.25,25.54.25,51.54.16,78,0,2.23,0,4.45,0,6.68l0,20q0,13.31,0,26.63c0,64.15,0,128.82-.14,192.74,0,2.29,0,4.57,0,6.89.19,7.68.19,15.68-.06,23.59"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-14)" />
      <path d="M128.25,251.71C128,276,128,299,128.08,323.23c0,2,0,4.11,0,6.16q0,21.58,0,43.16c0,9.24,0,18.48,0,27.66,0,54.27,0,108.08.09,162.25,0,2.35,0,4.71,0,7.06-.13,21.48-.13,43.48.12,64.8"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-15)" />
      <path d="M141.75,248.47c.25,19.53.25,39.53.19,59q0,3.28,0,6.61,0,3.14,0,6.27,0,22,0,44v28.31c0,56.84,0,114.06-.07,170.89,0,2.28,0,4.55,0,6.82.11,23.6.11,46.6-.14,70.6"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-16)" />
      <path d="M148.5,237.19c-.5,24.81-.5,49.81-.34,74.9,0,2.29,0,4.5,0,6.7q-.09,36-.08,71.89,0,14.35,0,28.67c.65,49.45-.63,98.59-.6,147.94,0,2.35,0,4.7,0,7.06C150,595,147,617,148.5,638"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-17)" />
      <path d="M162,218.14v425" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-18)" />
      <path d="M168.75,218.75C169,253,169,288,169,321.92v6.56q0,42.58,0,85.07,0,18.43,0,37C169,517,169,583,168.75,649.25" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-19)" />
      <path d="M175.5,225.28C175,254,175,283,175.1,312c0,2.21,0,4.33,0,6.45-.05,31.34,0,62.62,0,94,0,12.37,0,24.76,0,37.26-.14,66-.14,132.63.31,198.72,0,2.28,0,4.56.05,6.87"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-20)" />
      <path d="M182.25,235.49C182,261,182,286,182.05,311.7q0,3.36,0,6.7c0,31.18,0,62.34,0,93.12,0,12.49,0,25,0,37.57C182,512.91,182,576,182.18,640q0,3.56,0,7.11c-.2,4.93-.2,10.93.05,15.62"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-21)" />
      <path d="M195.75,246.05c.25,13.95.25,26.95.19,41.45,0,2.29,0,4.63,0,7,0,28,0,56.06,0,84.29q0,15.63,0,31.33c0,12.58,0,25.16,0,37.88q0,20.5,0,41.08,0,73.84-.09,148c0,2.36,0,4.72,0,7.08.15,12.86.15,25.86-.1,39"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-22)" />
      <path d="M202.5,240.67C202,257,202,272,202.11,288c0,2.15,0,4.32,0,6.48q-.09,42.24,0,84.18,0,15.7,0,31.4c0,12.6,0,25.19,0,37.93q-.06,31.51-.07,62.88c0,10.46,0,20.91,0,31.23,0,33.71-.06,67.45.15,101.3,0,2.26,0,4.53,0,6.85-.26,12.8-.26,24.8.24,37.34"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-23)" />
      <path d="M209.25,231.32C209,250,209,268,209.05,287.37v6.54c0,28.37,0,56.73,0,84.66q0,15.71,0,31.42c0,12.6,0,25.19,0,37.94q0,31.9,0,63.79v31.77c0,34.13,0,69.1.08,103.66,0,2.31,0,4.61,0,7C209,665,209,676,209.25,687"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-24)" />
      <path d="M216,224.51V686.57" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-25)" />
      <path d="M229.5,213.72c-.5,16.28-.5,32.28-.14,48.61,0,2.19,0,4.37,0,6.54q-.17,55.19-.2,110.49,0,15.61,0,31.23-.06,37.65-.07,75.08,0,18.72,0,37.41C230,579,227,635,229.5,690.88"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-26)" />
      <path d="M236.25,206.44C236,225,236,245,236.18,263.55c0,2.24,0,4.41,0,6.58q-.09,55-.1,110.23,0,15.58,0,31.16,0,42,0,84v28c0,56.41,0,112.41.22,168.81"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-27)" />
      <path d="M243,203.86V692.92" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-28)" />
      <path d="M263.25,231.46C263,241,263,250,263.2,260.31c0,2.21,0,4.41,0,6.62q-.1,56.22-.12,112.62,0,18.24,0,36.51,0,35.6,0,71.37V523.2q0,14.7,0,29.41c0,45.39,0,91.39.23,136.63"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-29)" />
      <path d="M270,236.79v450" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-30)" />
      <path d="M276.75,240.06c.25,8.94.25,16.94.05,26,0,2.18,0,4.35,0,6.52q.1,55.18.12,110.61,0,17.92,0,35.88,0,34.47,0,68.78v34.34q0,13.93,0,28v28.06c0,13,0,26.23,0,39.49v6.63c0,19.62,0,38.62-.23,58.78"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-31)" />
      <path d="M290.21,238.18c-.21,15.82-.21,31.82,0,47.39,0,2.13,0,4.25,0,6.38q-.07,47.83-.1,95.85,0,17.58,0,35.21,0,32.63,0,65.41v32.84q0,13.44,0,26.82v26.73c0,10.69,0,21.45,0,32.22,0,2.16,0,4.31,0,6.47,0,17.5,0,34.5.23,51.19"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-32)" />
      <path d="M297,234.74c0,18.26,0,37.26,0,55.54V655.17" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round"
                    stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-33)" />
      <path d="M303.8,237c.2,14,.2,29,.05,43.38,0,2.49,0,4.76,0,7q.09,48.4.12,96.65,0,21.45,0,42.89,0,21,0,41.95t0,41.86q0,27.12,0,54.18,0,13.53,0,27,0,6.5,0,13.08v6.58c0,13.35,0,27.35-.23,40.72"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-34)" />
      <path d="M310.66,247.93c.34,13.07.34,25.07-.27,37.59,0,2.3,0,4.56,0,6.79q-.17,47-.22,94.14,0,21.26,0,42.51,0,20.51-.06,40.94t0,40.89c0,17.74,0,35.34,0,52.9q0,13.17,0,26.32,0,9.74,0,19.49V616c0,13,0,26,.46,39.12"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-35)" />
      <path d="M317.48,259.24C317,269,317,279,317.19,288.89c0,2.15,0,4.29,0,6.44q-.07,41.87-.11,83.9,0,19.39,0,38.79,0,15.75,0,31.54t0,31.61c0,30.92,0,61.62,0,92.31q0,15.35,0,30.69c0,2,0,4,0,6s0,4,0,6c0,13.81,0,28.81.21,43"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-36)" />
      <path d="M337.5,274.76q-.06,3.09-.1,6.33c0,2.15-.06,4.31-.08,6.45-.32,25.76-.3,50.68-.21,76q0,3.39,0,6.76,0,20.27,0,40.54,0,16.89.05,33.78,0,18.34-.05,36.69c.77,48.93-1.19,97.36-.42,146.55.16,9.84.42,19.71.84,29.62"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-37)" />
      <path d="M344.25,275.38c0,2.2,0,4.46-.05,6.72-.2,29.47-.2,59.19-.13,89,0,2.15,0,4.3,0,6.45q0,9.69,0,19.37,0,19.35,0,38.68,0,18.84,0,37.78c0,60.63,0,121.63.21,182.17"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-38)" />
      <path d="M351,274.92V654.14" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-39)" />
      <path d="M357.75,275.8c.25,32.2.25,63.2.18,95.34v6.19q0,12.35,0,24.71,0,18.52,0,37.07T358,476q0,64.63-.06,129.23c0,2.27,0,4.54,0,6.82.11,14.92.11,28.92-.14,43.73"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-40)" />
      <path d="M364.5,280.91c-.5,30.09-.5,60.09-.35,90.14,0,2.27,0,4.53,0,6.8q0,13.57,0,27.15,0,18.11,0,36.22c.15,12.13.18,24.27.16,36.46-.19,40.37-.73,80.6-.55,120.72q0,3.35,0,6.7C364,624,364,643,364.5,662"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-41)" />
      <path d="M378,303.73V675.3" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-42)" />
      <path d="M384.75,311.81C385,325,385,338,384.89,351c0,2.18,0,4.35,0,6.52q.09,42.27,0,84.53,0,13,0,26c.06,44.56.07,88.59,0,132.84,0,2.34,0,4.69,0,7.13.11,20,.11,41-.14,61.38"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-43)" />
      <path d="M391.5,317.51C390,322,391,326,391,329.68l-.18,6.32c-.68,27.41-.22,54.83.15,82.24.15,11.24.29,22.49.33,33.73-.23,49.52-.85,98.47-.52,147.75l.06,7.08c.15,17.2.15,35.2.65,52.46"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-44)" />
      <path d="M398.25,323a105.66,105.66,0,0,0,0,12.07q0,3.21,0,6.43-.13,41.81-.14,83.73,0,17.19,0,34.44c-.05,47.53-.06,94.28.05,141.42,0,2.24,0,4.49,0,6.74C398,622,398,637,398.25,651.42"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-45)" />
      <path d="M405,328v5.92c0,2.06,0,4.18,0,6.32V647.59" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round"
                    stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-46)" />
      <path d="M418.51,338.85c-1.31,33.93-1.12,67.55-.74,101.2q.19,16.81.4,33.73C418,531,418,588,418.5,645.36" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-47)" />
      <path d="M425.26,345.23q-.13,37.89-.17,75.84,0,12.66,0,25.32-.06,56.24,0,112.82c0,2.36,0,4.71,0,7.07-.06,25.72-.06,50.72.19,77"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-48)" />
      <path d="M432,351.92q0,41.67,0,83V637.24" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-49)" />
      <path d="M438.76,358.82q.14,40,.17,80.34,0,13.41,0,26.88c0,27.21,0,54.22,0,81.18,0,2.25,0,4.49,0,6.74,0,25,0,49-.21,73.81"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-50)" />
      <path d="M445.51,365.8c-.94,25.95-1.11,51.87-1,77.79q.06,13,.21,26c.58,26.51.67,52.72.66,78.88V555c-.41,21-.41,42,.09,63.49"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-51)" />
      <path d="M452.26,372.76q-.06,18.81-.11,37.67t-.06,37.74c0,31.92-.07,63.62,0,95.31,0,2.26,0,4.53,0,6.79-.05,21.73-.05,44.73.2,66.5"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-52)" />
      <path d="M465.76,386.11c.24,19.89.24,38.89.14,59.14,0,2,0,3.93,0,5.9s0,3.94,0,5.9c0,31.74.06,63.79,0,95.88v6.86c.05,23.21.05,47.21-.2,69.84"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-53)" />
      <path d="M472.51,389.46C471,409,473,430,471.5,450.14v11.47c.81,30.9.31,62,.07,92.95,0,2.22,0,4.43-.05,6.64C470,585,473,609,472.5,632.74"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-54)" />
      <path d="M479.26,387.94C479,410,479,432,479.1,454.43c0,1.89,0,3.75,0,5.61v5.57C479,521,479,577,479.25,632.3" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-55)" />
      <path d="M492.76,381.43c.24,26.57.24,53.57.14,80.32,0,1.75,0,3.51,0,5.26s0,3.51,0,5.26C493,525,493,577,492.75,629.59" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-56)" />
      <path d="M499.51,392.49c-2.51,22.51.49,44.51-1,67.73,0,1.72,0,3.43,0,5.14q0,5.11,0,10.2c-.46,47.77,2.09,94.29,1.26,141.82-.07,3.66-.15,7.33-.26,11"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-57)" />
      <path d="M506.26,407.18C506,424,506,441,506.12,458c0,1.67,0,3.35,0,5q0,7.53,0,15c-.07,40.89-.09,81.13.05,121.9q0,3.39,0,6.8c-.16,7.28-.16,14.28.09,21"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-58)" />
      <path d="M526.51,416.59C524,444,527,470,525.59,496.82q0,3.36,0,6.72c.13,26.84-.13,53.42.09,80.06l.06,6.66c.22,22.74.22,45.74.72,68.51"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-59)" />
      <path d="M533.26,408.16C533,438,533,468,533.08,497.77c0,2.22,0,4.4,0,6.59,0,26.17,0,52.15,0,78.41q0,3.29,0,6.58C533,618,533,648,533.25,677.24"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-60)" />
      <path d="M540,404.38V678.52" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-61)" />
      <path d="M546.76,410.76C547,441,547,471,547,500.84v5q0,36.15,0,72.18l0,10.31c.05,15.41.08,30.56,0,45.83q0,4.58,0,9.18c.11,5.64.11,12.64-.14,18.75"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-62)" />
      <path d="M553.53,422c-1.53,25,.47,50-.64,74.58,0,1.66,0,3.31.05,5s0,3.3,0,4.94c-.62,23.33.7,46.86,1.18,70.18q.09,4.37.14,8.73c-.22,3.1-.32,6.24-.34,9.4s0,6.37.1,9.6c0,6.29.45,12.69.63,19.18.06,2.17.08,4.34,0,6.52C555,634,554,639,553.5,643.44"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-63)" />
      <path d="M560.34,429.25a107.52,107.52,0,0,0-.19,12.58q0,3.1,0,6.22c-.1,14.51-.09,29.13-.07,43.56v4.89q0,4.89,0,9.78c0,21.42,0,43.28,0,65,0,3.11,0,6.21,0,9.32q0,3.58,0,7.23c0,12.61,0,25.82.1,38.47q0,3.81.11,7.57"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-64)" />
      <path d="M580.57,416.61C579,424,581,431,580,438.48c0,1.6.07,3.2.08,4.79a108.38,108.38,0,0,1-.55,14.1c0,3.1,0,6.19-.06,9.28q0,9.27,0,18.56c.14,10.7.36,21.41.6,32.13s.5,21.46.69,32.21c-.24,6.7-.1,13.46.11,20.23.07,2.28.16,4.57.24,6.91-.07,11.54.36,22.94.2,34.28,0,2.83-.11,5.66-.24,8.5s-.31,5.73-.56,8.68"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-65)" />
      <path d="M587.31,403.43C587,417,587,431,587.05,444.73c0,1.71,0,3.43,0,5.17s0,3.49,0,5.26,0,3.26,0,4.87q0,11.81,0,23.57,0,16.27-.05,32.48t0,32.38c0,4.49,0,8.95,0,13.41v6.7c0,14.29,0,27.94.05,41.56,0,3.4,0,6.81.07,10.26s.07,7,.11,10.76"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-66)" />
      <path d="M594.06,400.19C594,413,594,425,594,437.74c0,2.16,0,4.24,0,6.34s0,4,0,6.05c.06,2.18.11,4.24.18,6.37,0,1.91,0,3.82,0,5.73q0,17.11,0,34.1c0,9.67,0,19.29,0,28.91s0,19.21,0,28.83v82.1"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-67)" />
      <path d="M600.81,407c.19,14,.19,27,0,41.18.06,2.11.1,4.16.16,6.26,0,1.94,0,3.89,0,5.83q0,17.42,0,34.7c0,19.52,0,38.78,0,58.09,0,3.63,0,7.25,0,10.88,0,15.67,0,31.31,0,46.83,0,3.11,0,6.21-.05,9.32.11,6.92.11,12.92-.14,20.13"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-68)" />
      <path d="M607.59,409.64C606,424,608,438,606.92,452.06c0,2,0,3.94-.07,5.91q0,14.25.06,28.49c.05,20.77.07,41.4.14,62.09,0,3.88,0,7.76.05,11.64s0,7.78.06,11.78c-.1,14.39-.14,28.39,0,42.43q0,4.22.08,8.46a157.9,157.9,0,0,0,.29,18.32"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-69)" />
      <path d="M621.14,402.65q-.21,27.53-.08,54v5.06q0,7.57,0,15c0,26.91,0,54.08,0,81.2v82.23" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-70)" />
      <path d="M627.88,401.72c.12,17.28.12,35.28.06,51.84,0,1.76,0,3.5,0,5.24,0,5.15,0,10.29,0,15.39,0,26.89,0,54.2,0,81.53q0,5.13,0,10.25c0,3.42,0,6.83,0,10.26.1,18.17.11,36.52-.06,55.16q0,4-.08,8"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-71)" />
      <path d="M641.38,403.1c-.38,11.9-.38,24.9-.16,37.1,0,2.08,0,4.09,0,6.13,0,9.81-.06,19.59-.08,29.25q-.14,51.09,0,101.56c0,3.74,0,7.51,0,11.49-.15,15.37-.15,31.37.1,46.51"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-72)" />
      <path d="M654.87,397.47q0,19,0,38.29c0,12.84,0,25.71,0,38.51q0,49-.05,98.29l0,9.85q0,3.39,0,6.83c0,2.29,0,4.59,0,6.92,0,9.84,0,20.84-.2,30.5"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-73)" />
      <path d="M661.61,393.83q-.4,19.28-.6,38.92t-.26,39.34c.18,33.17.23,66.39.42,99.55,0,3.69,0,7.37.07,11.06,0,2.22-.07,4.42-.1,6.62s0,4.4,0,6.58c-.09,9.1-.09,17.1.41,26.51"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-74)" />
      <path d="M668.35,404.24C668,421,668,437,668.09,453.55c0,1.95,0,3.89,0,5.84-.09,40.55-.1,80.73,0,121.25,0,3.68,0,7.37,0,11.11q-.06,3.46-.09,6.9c0,2.29,0,4.58,0,6.87,0,4.48,0,9.48.2,13.93"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-75)" />
      <path d="M681.84,385.09C682,403,682,422,682,440.38c0,2.05,0,4.11,0,6.16,0,10.75,0,21.58,0,32.35,0,39.19,0,78.31-.1,117.16l0,6.87c.18,5.08.18,10.08-.07,14.65"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-76)" />
      <path d="M702.06,375.54q0,23.59,0,46.86t0,46.23q0,56,0,111.65v60" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round"
                    stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-77)" />
      <path d="M708.8,373.29c.1,19.86.15,40,.17,60.23,0,10.1,0,20.21,0,30.27,0,37.69,0,75.78-.07,113.7q0,3.35,0,6.69c.06,10.84.09,21.74.06,32.63,0,2.19,0,4.37,0,6.58.07,9.61.07,19.61-.18,29.38"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-78)" />
      <path d="M722.28,369.52c-.14,21.74-.21,43.61-.24,65.42q0,16.35,0,32.62c0,38.56,0,76.4.06,114.38,0,2.23,0,4.47,0,6.7-.06,9.65-.09,18.87-.06,28.12,0,2.31,0,4.62,0,7-.09,5.29-.09,11.29.16,16.63"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-79)" />
      <path d="M729,367.71c0,4.29,0,9.29,0,13.09v6.51c0,15.18,0,30.43,0,45.67V635" transform="translate(1.25 -189.25)" fill="none"
                    stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-80)" />
      <path d="M735.76,363.86C736,373,736,383,735.88,392c0,2.17,0,4.33,0,6.5q0,16.2.06,32.5t0,32.56c0,46.37,0,91.82-.1,137.69,0,2.19,0,4.37,0,6.57.11,6.86.14,13.08,0,19.68,0,2.2-.08,4.44-.14,6.79"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-81)" />
      <path d="M742.51,356.74c-1.51,13.26.49,27.26-1,40.45q0,3.24,0,6.46c0,8.61.07,17.2.19,25.79.14,10.74.32,21.46.38,32.16-1,58.4,3,117.4.46,175.18"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-82)" />
      <path d="M749.25,347.61C749,366,749,384,749.09,402.38c0,2.13,0,4.27,0,6.41L749,428q0,16,0,32c0,57.73,0,114.5.19,172.5l0,7"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-83)" />
      <path d="M756,342.24c0,19.76,0,38.76,0,58.65V642.55" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round"
                    stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-84)" />
      <path d="M769.47,352.13C769,367,769,381,769.23,396.28l0,5.88q-.09,20.46-.12,40.89,0,13.63,0,27.3c0,47.37-.06,95.62.2,143.36q0,3.42,0,6.82c-.3,11.47-.3,23.47.2,34.88"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-85)" />
      <path d="M776.21,357.77C776,371,776,383,776.1,395.65c0,2,0,3.9,0,5.85q0,20.47-.06,41v27.3c0,48.65,0,97.8.1,146.45,0,2.33,0,4.67,0,7-.15,13.77-.15,26.77.1,40.55"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-86)" />
      <path d="M796.43,359.35Q796,413,796.06,467q0,13.49,0,27c-.07,44.36-.09,88.7.16,133.26,0,2.36,0,4.72,0,7.12C796,644,796,655,796.5,665.19"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-87)" />
      <path d="M803.18,358.85c-.12,36.1-.16,71.69-.15,107.39q0,13.38,0,26.8,0,70.21.09,140.4c0,2.23,0,4.46,0,6.69C803,649,803,658,803.25,667"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-88)" />
      <path d="M823.42,358.06c-.35,44.95-.41,90.64-.34,136.09q0,13.64,0,27.21c0,18.8-.08,37.78-.07,56.79v11.41C823,611,823,632,823.5,652.79"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-89)" />
      <path d="M830.17,358.13C830,365,830,371,830.11,378.37c0,2.25,0,4.49,0,6.74Q830,439,830,493q0,13.49,0,27,0,31,0,61.93,0,5.16,0,10.31c0,22.83,0,45.83.22,69.05"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-90)" />
      <path d="M836.92,356.15q.12,17.78,0,36.06c0,2.24,0,4.48,0,6.71q0,53.68,0,106.85c0,10.91,0,22,0,33q0,21.53,0,43v90.73" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-91)" />
      <path d="M843.67,350.66c.33,16.34.33,32.34.2,48.54q0,3.33,0,6.67.15,50,.05,100.21c0,11,0,22.22,0,33.42q0,22.08,0,44.22v11.07c0,30.21,0,59.21-.23,89.38"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-92)" />
      <path d="M850.42,343.29C850,362,850,381,850.18,399.89l0,6.6c-.15,37.39-.14,74.83-.1,112,0,12.83,0,25.74,0,38.6.28,13.4.23,26.8.07,40.2,0,3.35-.08,6.7-.13,10,0,28.65,0,57.65.52,86.3"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-93)" />
      <path d="M863.93,346.21C864,363,864,380,864,397.39q0,3.44,0,6.79c0,40.38,0,80.31,0,120.78q0,19.41,0,38.79v64c0,25.27,0,50.27,0,75.42"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-94)" />
      <path d="M870.68,357.17c.32,11.83.32,23.83.15,36,0,2.36,0,4.67,0,7,.15,39,.14,78.23.12,116.85q0,20.53,0,41.19V565c0,46,0,91-.18,137.16"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-95)" />
      <path d="M877.44,365.77C877,376,877,386,877.24,395.52c0,2.28,0,4.56,0,6.84-.2,38.78-.19,78.06-.15,116.91q0,17.25,0,34.49v6.87c1,46.37-2,91.37.54,137.72"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-96)" />
      <path d="M884.19,370.88c-.19,5.12-.19,9.12-.05,14.06q0,3.46,0,6.95-.18,66-.1,132.2v27.44c0,47.47,0,95.47.21,142.56" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-97)" />
      <path d="M891,374c0,51,0,102,0,152.68V554.1c0,45.9,0,92.9-.23,138.54" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round"
                    stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-98)" />
      <path d="M904.46,380.15C904,426,904,473,904.05,518.69q0,11.77,0,23.57v7.85C904,601,904,651,904,702.33" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-99)" />
      <path d="M911.22,383.27C911,419,911,454,911,490.29c0,10.38,0,20.85,0,31.33v27.51c0,49.87,0,100.87-.22,150.62" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-100)"
                />
      <path d="M918,386.33c0,36.67,0,74.67,0,111.93v52.62c0,49.12,0,98.12-.25,146.69" transform="translate(1.25 -189.25)" fill="none"
                    stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-101)" />
      <path d="M924.74,389.21c.26,37.79.26,76.79.23,115V538.8q0,4.34,0,8.65v8.6c0,48,0,97-.29,144.72" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-102)"
                />
      <path d="M931.5,391.74C931,430,931,468,931.07,506.46q0,17.2,0,34.39V558c1,50-2,99,.5,149.06" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-103)"
                />
      <path d="M938.25,393.84C938,430,938,466,938,502.29q0,17.61,0,35.23v47.76c0,3.56,0,7.11,0,10.62,0,34.1,0,68.1.28,102.21" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-104)"
                />
      <path d="M951.75,396.71C952,427,952,457,952,486.56q0,18.78,0,37.6c0,12.54,0,25.09,0,37.57v11.2q0,5.6,0,11.18c0,33.89,0,66.89-.23,100.77"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-105)" />
      <path d="M958.5,397.58C958,428,958,458,958.11,488q0,18.65,0,37.32c0,12.45,0,24.9,0,37.27,0,3.75,0,7.49,0,11.22s0,7.46,0,11.18c0,31.06,0,63.06.46,93.57"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-106)" />
      <path d="M965.25,398.1c-.25,17.9-.25,34.9-.17,53.26q0,18.4,0,37,0,16.23,0,32.51t0,32.56q0,10.23,0,20.44v10.21c0,30.92,0,62.92.23,93.69"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-107)" />
      <path d="M972,398.23V682.75" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-108)" />
      <path d="M985.53,397.25c-.64,12.08-.92,24.27-1,36.59s0,24.76.2,37.19q.1,34.13.17,68.23c0,11.37,0,22.73.07,33.9q0,5,0,10v10c0,34.78,0,70.78.53,105.34"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-109)" />
      <path d="M992.3,396q-.12,16.38-.17,32.75t-.08,32.75q0,35.07,0,70v34.89c0,32.57,0,66.57.23,99.09" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-110)"
                />
      <path d="M999.07,394.07c0,10.93,0,22,0,33.06s0,22.25,0,33.39q0,35.06,0,69.87V677.75" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-111)"
                />
      <path d="M1005.83,391.41q.07,16.69.1,33.66t0,34q0,34.47,0,69.12v45.14c0,36.67,0,74.67-.23,112" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-112)"
                />
      <path d="M1019.36,382.37c-.36,6.63-.36,12.63-.12,19.15l0,5.93-.06,11.87q-.07,17.82-.09,35.67,0,34.51,0,68.85v34.32c0,3.21,0,6.42,0,9.62v9.6c0,40.62,0,82.62.14,124"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-113)" />
      <path d="M1039.63,347.44C1038,368,1040,388,1038.75,409c0,2,0,4,0,6-.06,16,.07,31.89.19,47.84q.13,16,.2,32,0,18.79,0,37.49t0,37.33c0,33.25,0,66.31.16,99.12,0,2.26,0,4.52,0,6.86-.22,14.35-.22,27.35-.14,41.2"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-114)" />
      <path d="M1053.14,345.35C1053,365,1053,384,1053,403.8v6.49q0,22.57,0,45.19V671.1c0,9.9,0,20.9-.23,31.3" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-115)"
                />
      <path d="M1059.89,342.88c.11,18.12.11,37.12.09,55v6.72c0,15.56,0,31.08,0,46.42q0,18,0,36,0,37,0,73.7c0,12.26,0,24.49,0,36.55q0,39.82-.09,80.27c0,2.11,0,4.22,0,6.36a115,115,0,0,1-.16,13.35"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-116)" />
      <path d="M1066.63,336.66C1066,354,1066,372,1066.12,389l0,6.54q-.1,29.4,0,59,0,19.77,0,39.56,0,35,0,70.24c0,11.74,0,23.48,0,35.06-.07,29.41-.07,59.1.33,88.69,0,2.29.06,4.57.1,6.86"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-117)" />
      <path d="M1086.87,313.18c.13,32.82.13,65.82.09,99.2q0,16.59,0,33.2v33.23q0,16.62,0,33.24,0,31,0,62.24,0,15.62,0,31.21c0,28.5,0,58.5-.22,87.91"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-118)" />
      <path d="M1093.61,305.88c-1,56.95-1,113.46-.83,170.16q0,17,.11,34,0,15.72,0,31.46C1094,593,1091,643,1093.5,693.93" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-119)"
                />
      <path d="M1107.1,292.88c-.1,4.12-.1,8.12,0,12.31v6.51c0,45.55-.06,91.31-.07,137q0,15.67,0,31.35V695.61" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-120)"
                />
      <path d="M1113.84,289.28c.16,5.72.16,10.72,0,16.37v6.51q.09,72.19.1,144.64V491c0,68,0,137-.22,205.51" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-121)"
                />
      <path d="M1120.58,287.09C1119,294,1120,300,1120,307.17c0,2.2-.06,4.45-.1,6.7-.6,42.78-.48,85.7-.23,128.59q.12,20.32.26,40.57c0,71,0,143,.53,214.21"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-122)" />
      <path d="M1140.8,270.88c.2,12.12.2,23.12.06,35.45q0,3.38,0,6.73.08,50.51.09,100.85V450.8c0,75.35,0,151.37-.15,227,0,2.32,0,4.64,0,7,.21,5.18.21,10.18,0,15.67"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-123)" />
      <path d="M1147.54,263.25C1146,274,1148,284,1147,294.56c0,2.11-.06,4.25-.09,6.4-.37,30.08-.43,60.13-.36,90.17q.06,21.45.18,42.89c.27,78.72.3,157.45.66,236.38q0,3.48,0,7a261.91,261.91,0,0,0,.11,26.42"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-124)" />
      <path d="M1154.28,259.23q-.15,65.11-.21,130.65,0,21.83,0,43.6c0,76,0,153.12.12,229.6,0,2.32,0,4.64,0,6.95-.18,12-.18,25,.07,36.59"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-125)" />
      <path d="M1167.76,255.06c.24,11.94.24,22.94.07,34.74,0,2.31,0,4.61,0,6.92q.08,41.47.1,82.87,0,20.71,0,41.35c0,84.23,0,169.27-.15,253.77,0,2.34,0,4.71,0,7.23.21,6.06.21,12.06,0,18.22"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-126)" />
      <path d="M1174.51,251.33c-1.51,13.67.49,27.67-.65,41.26,0,2.23-.06,4.4-.08,6.56-.3,27.72-.34,55.46-.27,83.22,0,14.24.1,28.48.18,42.59.29,82,.31,164.84.7,247.13,0,2.36,0,4.72,0,7.1a87.74,87.74,0,0,0,.07,15.63"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-127)" />
      <path d="M1181.25,244.14c-.25,20.86-.25,42.86-.11,64.18q0,3.38,0,6.75,0,30.38-.07,60.83c0,13.54,0,27.07,0,40.51,0,89.3,0,178,.21,267.48,0,2.32,0,4.64,0,7"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-128)" />
      <path d="M1188,235.41c0,24.59,0,48.59,0,73.3v89.16c0,97.13,0,193.13,0,290" transform="translate(1.25 -189.25)" fill="none"
                    stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-129)" />
      <path d="M1201.47,239.39C1201,262,1201,285,1201.3,308q0,3.06,0,6.12,0,15.3-.08,30.61,0,21.45-.08,42.9C1201,486,1201,583,1201.5,681"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-130)" />
      <path d="M1208.21,251.73c-.21,15.27-.21,31.27-.06,46.49,0,2.2,0,4.29,0,6.37q0,21.41-.05,42.81t0,42.76c0,95.84,0,190.84.2,286.9"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-131)" />
      <path d="M1215,262c0,13,0,27,0,39.61q0,3,0,6.09,0,21.34,0,42.65t0,42.5c0,93.18,0,187.18,0,280.06" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-132)"
                />
      <path d="M1221.69,268.46c.31,7.54.31,16.54.06,24.42,0,2,0,4,0,6.06q.06,27.29.1,54.48c0,14.11,0,28.2.05,42.16.08,91.42.08,181.42-.17,272.92"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-133)" />
      <path d="M1235.17,277.17q0,20.79-.05,41.53t0,41.46c0,68.94-.06,137.47,0,206.35q0,3.57,0,7.11c-.09,28.38-.09,56.38.16,84.5"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-134)" />
      <path d="M1241.92,282q0,20.45,0,40.87t0,40.87q0,97.23,0,194.18v90.6" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round"
                    stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-135)" />
      <path d="M1255.4,292.7q-.08,18.06-.13,36.06t-.1,36c-.11,63.63-.15,126.69,0,189.89,0,2.34,0,4.68,0,7-.18,21.38-.18,41.38.32,62.77"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-136)" />
      <path d="M1262.14,298.4q0,17.55,0,35.12t0,35.15q-.06,92.47,0,184.61c0,2.27,0,4.55,0,6.82-.09,20.9-.09,40.9.16,61.57" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-137)"
                />
      <path d="M1275.63,311.2c.37,16.8.37,32.8.17,49.45,0,1.86,0,3.72,0,5.58q0,5.59,0,11.17.06,32.1.09,64.27,0,16.08,0,32.18c0,29.33,0,58.33,0,87.33q0,3.35,0,6.68c0,21.14,0,41.14-.2,62.53"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-138)" />
      <path d="M1282.38,321.68c-.38,14.32-.38,29.32-.18,43.81,0,1.82,0,3.64,0,5.45q0,5.46,0,10.88,0,20.79-.06,41.65t0,41.75c.54,32.54-.25,64.81-.51,97.22,0,2.32,0,4.63,0,6.95-1.51,20.61,1.49,41.61,1,62.24"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-139)" />
      <path d="M1289.12,332.92c-.12,12.08-.12,25.08,0,37,0,1.77,0,3.54,0,5.3q0,5.29,0,10.56,0,20.31,0,40.67c0,67.55,0,135.55.22,203.56"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-140)" />
      <path d="M1295.87,339.53c.13,10.47.13,19.47.06,29.85v5.35q0,13.38,0,26.82,0,60.12,0,120.53,0,3.55,0,7.09V628" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-141)"
                />
      <path d="M1316.13,344.51c-.13,6.49-.13,13.49,0,19.74,0,1.73,0,3.47,0,5.2s0,3.46,0,5.19c0,44.52,0,88.67,0,132.84,0,2.32,0,4.65,0,6.95,0,30.57,0,61.57.2,92.1"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-142)" />
      <path d="M1322.88,347.84c0,1.69,0,3.38,0,5.07s0,3.4,0,5.09q0,10.17,0,20.29.06,65.47.06,131.09v6.83q0,43.18,0,87" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-143)"
                />
      <path d="M1336.4,355q-.35,78.45-.27,156.92v6.79c-.13,33.25-.13,67.25.37,100.72" transform="translate(1.25 -189.25)" fill="none"
                    stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-144)" />
      <path d="M1343.16,357.78c-.09,52.23-.13,104.73-.1,157.13q0,3.57,0,7.14c-.07,35-.07,70,.18,104.62" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-145)"
                />
      <path d="M1349.93,359.87q.06,85.38.07,170.7v99.61" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round"
                    stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-146)" />
      <path d="M1363.47,361.86c-.47,14.14-.47,29.14-.19,42.84,0,2.38,0,4.75,0,7.13-.24,73.67-.17,147.79.24,221.39" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-147)"
                />
      <path d="M1370.24,358.78c-.24,17.22-.24,34.22-.11,51q0,3.44,0,6.85-.16,109.18.13,218.3" transform="translate(1.25 -189.25)"
                    fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" stroke="url(#linear-gradient-148)"
                />
      <path d="M1383.75,338.21c.25,25.79.25,51.79.12,77.55,0,2.38,0,4.72,0,7.06q.11,74.25,0,148.4c0,2.25,0,4.49,0,6.69.12,18.09.12,36.09-.13,54.48"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-149)" />
      <path d="M1390.5,331.2c-.5,27.8-.5,54.8-.24,83.28,0,2.47,0,4.84,0,7.21q-.21,71.49,0,143.35c0,2.29,0,4.57,0,6.85C1390,590,1390,608,1390.5,626"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-150)" />
      <path d="M1410.75,348.64c.25,20.36.25,39.36.12,59.25q0,3.54,0,7.05.11,74.81,0,149.61,0,3.39,0,6.8c.11,20.65.11,40.65-.14,61.93"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-151)" />
      <path d="M1417.5,349c-.5,17-.5,33-.21,50,0,2.37,0,4.75,0,7.12-.17,54.55-.19,109-.06,163.54,0,2.37,0,4.75,0,7.1-.23,22.24-.23,44.24.27,66.34"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-152)" />
      <path d="M1424.25,346.17c-.19,75.62-.23,151.9-.14,228,0,2.31,0,4.61,0,6.92-.06,11.47-.09,22.71-.07,34,0,1.88,0,3.76,0,5.65-.06,9.3-.06,19.3.19,28.8"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-153)" />
      <path d="M1431,343V655.15" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-154)" />
      <path d="M1444.5,339.59c-.5,13.41-.5,25.41-.17,38.42,0,2.28,0,4.6,0,6.91-.23,69-.24,137.71,0,206.7,0,2.38,0,4.76,0,7.14C1444,625,1444,651,1444.5,677"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-155)" />
      <path d="M1451.25,342.93c-.25,13.07-.25,26.07-.1,39.31,0,2.29,0,4.65,0,7-.1,68.41-.1,137,0,205.2,0,2.35,0,4.71,0,7.06-.14,27.5-.14,55.5.11,83"
                    transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-156)" />
      <path d="M1458,347.13V680.42" transform="translate(1.25 -189.25)" fill="none" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2.5" stroke="url(#linear-gradient-157)" />
      <g opacity="0.8">
        <circle cx="1121.63" cy="408.08" r="3" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" />
        <line x1="1121.63" y1="405.08" x2="1121.63" y2="389.86" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
        <line x1="1121.63" y1="426.81" x2="1121.63" y2="411.59" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
      </g>
      <g opacity="0.8">
        <circle cx="1020.14" cy="320.17" r="3" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" />
        <line x1="1020.14" y1="317.17" x2="1020.14" y2="301.95" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
        <line x1="1020.14" y1="338.9" x2="1020.14" y2="323.68" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
      </g>
      <g opacity="0.8">
        <circle cx="953" cy="359.89" r="3" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" />
        <line x1="953" y1="356.89" x2="953" y2="341.67" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" opacity="0.25"
                    />
        <line x1="953" y1="378.62" x2="953" y2="363.4" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" opacity="0.25"
                    />
      </g>
      <g opacity="0.8">
        <circle cx="905.51" cy="252.71" r="3" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" />
        <line x1="905.51" y1="249.71" x2="905.51" y2="234.49" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
        <line x1="905.51" y1="271.44" x2="905.51" y2="256.22" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
      </g>
      <g opacity="0.8">
        <circle cx="797.29" cy="289.66" r="3" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" />
        <line x1="797.29" y1="286.66" x2="797.29" y2="271.44" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
        <line x1="797.29" y1="308.39" x2="797.29" y2="293.17" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
      </g>
      <g opacity="0.8">
        <circle cx="683.4" cy="342.64" r="3" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" />
        <line x1="683.4" y1="339.64" x2="683.4" y2="324.42" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
        <line x1="683.4" y1="361.37" x2="683.4" y2="346.15" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
      </g>
      <g opacity="0.8">
        <circle cx="526.72" cy="355.49" r="3" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" />
        <line x1="526.72" y1="352.49" x2="526.72" y2="337.27" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
        <line x1="526.72" y1="374.21" x2="526.72" y2="358.99" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
      </g>
      <g opacity="0.8">
        <circle cx="467.16" cy="258.39" r="3" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" />
        <line x1="467.16" y1="255.39" x2="467.16" y2="240.17" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
        <line x1="467.16" y1="277.12" x2="467.16" y2="261.9" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
      </g>
      <g opacity="0.8">
        <circle cx="379.25" cy="364.37" r="3" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" />
        <line x1="379.25" y1="361.37" x2="379.25" y2="346.15" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
        <line x1="379.25" y1="383.1" x2="379.25" y2="367.88" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
      </g>
      <g opacity="0.8">
        <circle cx="183.27" cy="199.23" r="3" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" />
        <line x1="183.27" y1="196.23" x2="183.27" y2="181.01" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
        <line x1="183.27" y1="217.96" x2="183.27" y2="202.74" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
      </g>
      <g opacity="0.8">
        <circle cx="1351.04" cy="300.76" r="3" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5" />
        <line x1="1351.04" y1="297.76" x2="1351.04" y2="282.54" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
        <line x1="1351.04" y1="319.48" x2="1351.04" y2="304.26" fill="#fff" stroke="#44b4cc" stroke-miterlimit="10" stroke-width="2.5"
                        opacity="0.25" />
      </g>
      <line x1="244.25" y1="8.75" x2="244.25" y2="1.25" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-158)" />
      <line x1="102.27" y1="74.15" x2="102.27" y2="66.65" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-159)" />
      <line x1="365.75" y1="87.38" x2="365.75" y2="79.88" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-160)" />
      <line x1="541.25" y1="206.99" x2="541.25" y2="199.49" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-161)" />
      <line x1="1040.42" y1="152.71" x2="1040.42" y2="145.21" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-162)" />
      <line x1="1189.25" y1="36.04" x2="1189.25" y2="28.54" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-163)" />
      <line x1="1391.75" y1="127.68" x2="1391.75" y2="120.18" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                    stroke="url(#linear-gradient-164)" />
                    
                    <!--
    </svg>
    <div class="container">
      <div class="deposits-counter">
        <svg  viewBox="0 0 104.89 100.81">
          <use xlink:href="#servicesPageIcon"></use>
        </svg> </div> -->

      <!--<div class="investment-offer" style="margin-top: 0">
        <h2>What People Are Saying About Us</h2> -->
        <p class="cust-serv"> <div class="home-features" style="padding-bottom: 0px">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-4 "><!--
          <div class="home-features-item bitcoin">
            <svg viewBox="0 0 51.42 52.83">
              <use xlink:href="#bitcoin-home"></use>
            </svg>
            <strong>INSTANT WITHDRAWALS </strong>
            <p> We usually process withdrawal requests between 1–3 hours, but it is up to your payment system how long it will take the money to reach the destination as the confirmation on the Blockchain network may vary depending on your wallet provider.   </p>
          </div>-->
          
          <video width="320" height="240" controls>
  <source src="https://astroforex.net/styles/img/video1.mp4" type="video/mp4">
  <source src="https://astroforex.net/styles/img/video1.mp4" type="video/ogg">
</video>
        </div>
        <div class="col-md-4 col-sm-4 "><!--
          <div class="home-features-item time">
            <svg viewBox="0 0 58.58 50.99'
              <use xlink:href="#time-home"></use>
            </svg>
            <strong>5 TRADING DAYS</strong>
            <p> With 5 trading days in a week (Monday to Friday), our professionals will analyse the market condition to know the profitable hours to enter trades and make great profits and you can stop your investment at any time. </p>
          </div>-->
          <video width="320" height="240" controls>
  <source src="https://astroforex.net/styles/img/video2.mp4" type="video/mp4">
  <source src="https://astroforex.net/styles/img/video2.mp4" type="video/ogg">
</video>
        </div>
        <div class="col-md-4 col-sm-4 "><!--
          <div class="home-features-item investment">
            <svg viewBox="0 0 49.05 57.09">
              <use xlink:href="#investment-home"></use>
            </svg>
            <strong>SECURE AND RELIABLE </strong>
            <p> All transactions on AstroFX are secure and encrypted as your safety to us, comes first. We ensure a strong security on all accounts and when an unsual activity is detected, you will be prompted to do a verification challenge. Verification happens in real time </p>
          </div>-->
<video width="320" height="240" controls>
  <source src="https://astroforex.net/styles/img/video3.mp4" type="video/mp4">
  <source src="https://astroforex.net/styles/img/video3.mp4" type="video/ogg">
</video>        </div>
      </div>
    </div>
  </div></p>
        
      </div>
    </div>
  </div>
  
  <div class="home-features" style="padding-bottom: 30px">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-4 "><!--
          <div class="home-features-item bitcoin">
            <svg viewBox="0 0 51.42 52.83">
              <use xlink:href="#bitcoin-home"></use>
            </svg>
            <strong>INSTANT WITHDRAWALS </strong>
            <p> We usually process withdrawal requests between 1–3 hours, but it is up to your payment system how long it will take the money to reach the destination as the confirmation on the Blockchain network may vary depending on your wallet provider.   </p>
          </div>-->
<video width="320" height="240" controls>
  <source src="https://astroforex.net/styles/img/video4.mp4" type="video/mp4">
  <source src="https://astroforex.net/styles/img/video4.mp4" type="video/ogg">
</video>        </div>
        <div class="col-md-4 col-sm-4 "><!--
          <div class="home-features-item time">
            <svg viewBox="0 0 58.58 50.99">
              <use xlink:href="#time-home"></use>
            </svg>
            <strong>5 TRADING DAYS</strong>
            <p> With 5 trading days in a week (Monday to Friday), our professionals will analyse the market condition to know the profitable hours to enter trades and make great profits and you can stop your investment at any time. </p>
          </div>-->
<video width="320" height="240" controls>
  <source src="https://astroforex.net/styles/img/video5.mp4" type="video/mp4">
  <source src="https://astroforex.net/styles/img/video5.mp4" type="video/ogg">
</video>        </div>
        <div class="col-md-4 col-sm-4 "><!--
          <div class="home-features-item investment">
            <svg viewBox="0 0 49.05 57.09">
              <use xlink:href="#investment-home"></use>
            </svg>
            <strong>SECURE AND RELIABLE </strong>
            <p> All transactions on AstroFX are secure and encrypted as your safety to us, comes first. We ensure a strong security on all accounts and when an unsual activity is detected, you will be prompted to do a verification challenge. Verification happens in real time </p>
          </div>-->
<video width="320" height="240" controls>
  <source src="https://astroforex.net/styles/img/video6.mp4" type="video/mp4">
  <source src="https://astroforex.net/styles/img/video6.mp4" type="video/ogg">
</video>        </div>
      </div>
    </div>
  </div>
           </header>
           
           
  

<div class="investment-plan">
  <div class="container">
    <div class="plan-holder" style="margin-top:50px">
      <div class="row">
          <div class="col-md-2 col-sm-2 col-xs-2"></div>
          <div class="col-md-4 col-sm-4 col-xs-4">
            <div class="plan-item plan1">
              <div class="plan-body">
                  <h2 style="color:#000 !important">STANDARD</h2>
                <div class="plan-profit"> <strong>3.3<b>% daily</b></strong> <span> <br>for 3 days</span></div>
                <div class="plan-bg"></div>
                <div class="plan-bottom"> <span>Minimum Deposit:</span> <strong>$100<b></b></strong> <span>Maximum Deposit:</span> <strong>$5000</strong>
                <div class=""> 
								<a onclick="openModal('register-modal')" class="btn">Sign Up</a> 
								</div>
              </div>
            </div>
          </div>
          </div>

          <div class="col-md-4 col-sm-4 col-xs-4">
            <div class="plan-item plan2">
              <div class="plan-body">
                  <h2 style="color:#000 !important">PROFESSIONAL</h2>
                <div class="plan-profit"> <strong>6.0<b>% daily</b></strong> <span><br>for 5 Days</span></div>
                <div class="plan-bg"></div>
                <div class="plan-bottom"> <span>Minimum Deposit:</span> <strong>$5,000<b></b></strong> <span>Maximum Deposit:</span> <strong>$20,000</strong> 
                <div class=""> 
								<a onclick="openModal('register-modal')" class="btn">Sign Up</a> 
								</div>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-2 col-xs-2"></div>
      </div>
    </div>
  </div>
</div>
<div class="investment-plan">
  <div class="container">
    <div class="plan-holder" style="margin-top:50px">
      <div class="row">
          <div class="col-md-2 col-sm-2 col-xs-2"></div>
          <div class="col-md-4 col-sm-4 col-xs-4">
            <div class="plan-item plan1">
              <div class="plan-body">
                  <h2 style="color:#000 !important">ADVANCED</h2>
                <div class="plan-profit"> <strong>6.4<b>% daily</b></strong> <span> <br>for 7 Days</span></div>
                <div class="plan-bg"></div>
                <div class="plan-bottom"> <span>Minimum Deposit:</span> <strong>$10,000<b></b></strong> <span>Maximum Deposit:</span> <strong>Unlimited</strong>
                <div class=""> 
								<a onclick="openModal('register-modal')" class="btn">Sign Up</a> 
								</div>
              </div>
            </div>
          </div>
          </div>

          <div class="col-md-4 col-sm-4 col-xs-4">
            <div class="plan-item plan2">
              <div class="plan-body">
                  <h2 style="color:#000 !important">PREMIUM</h2>
                <div class="plan-profit"> <strong>15<b>% daily </b></strong><span>for 6-12 months</span> </div>
<!--                <div class="plan-bg"></div>-->
                  
                <div class="plan-bottom"> <span>Minimum Deposit:</span> <strong>$1,000<b></b></strong> <span>Maximum Deposit:</span> <strong>Unlimited</strong> 
                <div class=""> 
								<a onclick="openModal('register-modal')" class="btn">Sign Up</a> 
								</div>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-2 col-xs-2"></div>
      </div>
    </div>
  </div>
</div>
<div class="calculate-profit">
  <div class="container">
    <div class="row">
      <div class="col-md-6 ">
        <div class="calculate-profit__description">
          <div class="calculate-profit__icon">
            <svg viewBox="0 0 403.9 263.22">
              <use xlink:href="#calculateProfitIcon"></use>
            </svg>
          </div>
          <h2>Calculate your profit</h2>
          <p>Enter your desired trading amount:</p>
        </div>
      </div>
      <div class="col-md-6 ">
        <div class="investment-amount-input">
          <input id="txtAmount" type="text" value="200" placeholder="Amount to Deposit">
          <svg viewBox="0 0 7.51 13.67" stroke="#44b4cc">
            <use xlink:href="#btcIcon"></use>
          </svg>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="services-profit-holder">
  <div class="container ">
    <div class="services-profit">
      <h4 style="text-transform: uppercase; margin-bottom: 30px;">Select Your Trading Plan</h4>
      <div class="select-plan">
        <input type="radio" name="plan" class="planRadio" id="plan-1" checked>
        <label for="plan-1" class="select-plan-item">
          <b>3.3% daily</b> Profit
          <span>for 3 Days</span>
        </label>
        <input type="radio" name="plan" class="planRadio" id="plan-2">
        <label for="plan-2" class="select-plan-item">
          <b>6.0% daily</b>  Profit
          <span>for 5 Days</span>
        </label>
      </div>
      <div class="services-profit__detail">
        <div class="float-profit-svg services">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 346.47 410.99">
            <defs>
              <linearGradient id="linear-gradient-profit-services" x1="558.59" y1="275.14" x2="753.4" y2="275.14" gradientUnits="userSpaceOnUse">
                <stop offset="0" stop-color="#ff6873" />
                <stop offset="1" stop-color="#ff896c" />
              </linearGradient>
              <clipPath id="clip-path" transform="translate(-507.77 -176.92)">
                <path d="M752.92,273.24c-1.34,16.77-5.32,32.81-11.1,43.67-5.78,11.2-13.37,17.23-22.13,21.63s-18.73,7.2-29.44,12.15C679.53,355.34,668,362.17,656,367.57s-23.53,7.74-34.25,3.9C611,368,601.09,358.21,592.31,346.65c-17.47-25.57-30.49-50.47-33.23-68.56s5.94-46.78,23.54-74c8.77-12.67,19.7-22.77,32.18-25.86,12.47-3.45,26.48.09,41.2,6.61s28.73,14.42,41.2,19.24c12.48,5.17,23.41,7.29,32.18,10.51s15.37,7.55,19.4,17.36C752.81,241.46,754.26,256.42,752.92,273.24Z"
                                    fill="none" />
              </clipPath>
              <linearGradient id="linear-gradient-profit-services-2" x1="529.87" y1="425.18" x2="854.24" y2="425.18" gradientUnits="userSpaceOnUse">
                <stop offset="0" stop-color="#9f95ed" />
                <stop offset="1" stop-color="#a567a3" />
              </linearGradient>
              <linearGradient id="linear-gradient-profit-services-3" x1="507.77" y1="438.84" x2="834.44" y2="438.84" gradientUnits="userSpaceOnUse">
                <stop offset="0" stop-color="#69d2cd" />
                <stop offset="1" stop-color="#44a5d5" />
              </linearGradient>
            </defs>
            <path d="M755.88,280.67c2.28,10.26,3.2,21,1.31,32.11A100.21,100.21,0,0,1,747,341.88a41.92,41.92,0,0,1-16.31,18.46c-7.33,4.54-16.09,7.79-25.3,10.37-9,2.39-18.63,2.87-27.83,2.56-9.25-.67-18.35-1.66-27.52-3.17a217.09,217.09,0,0,0-24,.07c-9,.66-17.21.55-24.58-2.05s-14.24-8.56-20.37-17.1a185.74,185.74,0,0,1-11.53-19.54c-3.48-6.77-6.65-13.54-9.57-20.54-3.15-6.65-6.46-13.87-10.17-22.08a128.7,128.7,0,0,1-10-31.55c-1.61-11.34-1-21.27,2.12-29.18a39.67,39.67,0,0,1,15.5-18.66c7-4.65,15-8.37,23.12-11.8s15.61-7.23,22.9-10.66a79.8,79.8,0,0,1,23.3-7,102.48,102.48,0,0,1,21.39-.63c7.45.43,15.62,1,24.89.69s19.11-1.42,27.61-1.14,15,3,18.91,8.48,6.77,13.85,10.45,24.14,8.22,21.46,12.77,32.78q4.17,9.48,7.52,18.6C752.46,269,754.36,274.91,755.88,280.67Z"
                            transform="translate(-507.77 -176.92)" fill="none" stroke="#e8f3fc" stroke-miterlimit="10" stroke-width="3"
                        />
            <path d="M752.92,273.24c-1.34,16.77-5.32,32.81-11.1,43.67-5.78,11.2-13.37,17.23-22.13,21.63s-18.73,7.2-29.44,12.15C679.53,355.34,668,362.17,656,367.57s-23.53,7.74-34.25,3.9C611,368,601.09,358.21,592.31,346.65c-17.47-25.57-30.49-50.47-33.23-68.56s5.94-46.78,23.54-74c8.77-12.67,19.7-22.77,32.18-25.86,12.47-3.45,26.48.09,41.2,6.61s28.73,14.42,41.2,19.24c12.48,5.17,23.41,7.29,32.18,10.51s15.37,7.55,19.4,17.36C752.81,241.46,754.26,256.42,752.92,273.24Z"
                            transform="translate(-507.77 -176.92)" fill="url(#linear-gradient-profit-services)" />
            <g clip-path="url(#clip-path)">
              <path class="percent-path" d="M840.72,448c-26.43,35.59-63.65,65.51-89.39,88-27.09,22.32-42.69,37.21-56.88,39.11-14.18,1.65-29.77-10.89-56.85-37.49-25.73-26.24-63-66.53-89.38-112.07s-22.09-106-1.09-135.63c17.54-24.77,25.54,32.28,119.54,5.52,182.66-52,175,6.82,178,53.85C847.15,388.63,867.13,412.5,840.72,448Z"
                                fill="url(#linear-gradient-profit-services-2)" />
              <path class="percent-path" d="M820.92,460.67c-26.43,35.58-63.65,65.51-89.39,88-27.08,22.32-42.69,37.2-56.88,39.11-14.18,1.65-29.77-10.9-56.85-37.5C592.07,524,554.85,483.74,528.42,438.2s-28.25-111.48-1.09-135.62C553.14,278.08,566,318.33,662,301,847.19,267.56,821.89,314.92,824.86,362,827.35,401.29,847.33,425.17,820.92,460.67Z"
                                fill="url(#linear-gradient-profit-services-3)" />
            </g>
          </svg>
          <div>
            <strong id="lblProfit"></strong><b>%</b>
            <span id="lblProfitType"></span>
          </div>
          <small id="lblProfitPeriod" style="position:relative;"></small>
        </div>
        <div class="detail-left">
          <div><strong id="lblSelectedPlan"></strong></div>
          <div><span>Trading Plan</span></div>
          <div><strong id="lblDailyProfit"></strong><strong> USD</strong></div>
          <div><span>Profit</span></div>
        </div>
        <div class="detail-right">
          <div><strong id="lblTotalProfit"></strong><strong> USD</strong></div>
          <div><span>Total Profit</span></div>
          <div><strong id="lblTotalReturn"></strong><strong> USD</strong></div>
          <div><span>Total Return</span></div>
        </div>
      </div>
    </div>
  </div>
</div>
<footer>
    <div class="ready-to-start">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-sm-8 col-xs-7">
          <h2>Ready to get started?</h2>
                    <p>You are just few steps away from your first income. Make a new investment today. </p>
           </div>
        <div class="col-md-4 col-sm-4 col-xs-5 text-center">
				<a onclick="openModal('register-modal')" class="btn btn--blue" style="cursor: pointer">Create New Account</a> 
		 
		</div>
      </div>
    </div>
  </div>