

<div class="col-md-8 col-sm-8">
        <div class="referrals">
            <div class="dashboard-content__title">
                <svg viewBox="0 0 26.68 18.7">
                    <use xlink:href="#referralIcon"></use>
                </svg>
                My Referrals             </div>
            <div class="referrals-link">
                <div class="input-bylabel">
<!--                    <span>http://astroforex.net/?ref=Greg</span>-->
                    <span><?php echo create_reflink($m_username); ?></span>
                    <label>Your Referral Link:</label>
                </div>
                <a href="?a=cust&amp;page=promotion" class="btn btn--blue referrals-link__btn">Marketing Banners</a>
            </div>
			
			


			
				
				
            </div>
                                </div>
    </div>
</div>
</div>
</div>
<footer>     